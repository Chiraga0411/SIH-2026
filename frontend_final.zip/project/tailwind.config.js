/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ivory: {
          50: '#FBFAF7',
          100: '#F7F5F0',
          200: '#EFEDE6',
          300: '#E4E1D8',
        },
        graphite: {
          50: '#E8E8EA',
          100: '#C8C8CE',
          200: '#9A9AA6',
          300: '#6E6E7A',
          400: '#4A4A55',
          500: '#2E2E36',
          600: '#1E1E25',
          700: '#16161C',
          800: '#0E0E14',
          900: '#08080C',
        },
        steel: {
          50: '#F0F2F5',
          100: '#D8DCE3',
          200: '#B0B8C4',
          300: '#88929F',
          400: '#5E6A7A',
          500: '#3E4A5A',
          600: '#2A3441',
          700: '#1C242F',
        },
        accent: {
          50: '#EBF4FF',
          100: '#D0E5FF',
          200: '#9FCAFF',
          300: '#5FA6FF',
          400: '#2E82F0',
          500: '#0E63D0',
          600: '#0A4FA8',
          700: '#073D82',
        },
        amber: {
          400: '#F5B544',
          500: '#E09A2C',
          600: '#C47E1A',
        },
        safe: {
          400: '#3FB984',
          500: '#2DA06C',
          600: '#1E8557',
        },
        danger: {
          400: '#F06565',
          500: '#E04545',
          600: '#C02828',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Menlo', 'monospace'],
      },
      fontSize: {
        'editorial-xl': ['clamp(2.5rem, 6vw, 5.5rem)', { lineHeight: '1.05', letterSpacing: '-0.03em', fontWeight: '600' }],
        'editorial-lg': ['clamp(2rem, 4.5vw, 3.75rem)', { lineHeight: '1.1', letterSpacing: '-0.025em', fontWeight: '600' }],
        'editorial-md': ['clamp(1.5rem, 3vw, 2.5rem)', { lineHeight: '1.15', letterSpacing: '-0.02em', fontWeight: '600' }],
        'editorial-sm': ['clamp(1.25rem, 2vw, 1.75rem)', { lineHeight: '1.2', letterSpacing: '-0.015em', fontWeight: '500' }],
      },
      spacing: {
        '18': '4.5rem',
        '22': '5.5rem',
        '30': '7.5rem',
      },
      borderRadius: {
        'xl2': '1rem',
      },
      boxShadow: {
        'panel': '0 1px 2px rgba(14,14,20,0.04), 0 4px 16px rgba(14,14,20,0.06)',
        'panel-lg': '0 4px 8px rgba(14,14,20,0.06), 0 12px 40px rgba(14,14,20,0.10)',
        'inset-line': 'inset 0 -1px 0 rgba(14,14,20,0.06)',
        'accent-glow': '0 0 24px rgba(46,130,240,0.25)',
      },
      transitionTimingFunction: {
        'precision': 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
      animation: {
        'pulse-soft': 'pulse-soft 2.5s cubic-bezier(0.4,0,0.6,1) infinite',
        'scan-line': 'scan-line 3s linear infinite',
        'draw-line': 'draw-line 1.2s ease-out forwards',
      },
      keyframes: {
        'pulse-soft': {
          '0%,100%': { opacity: '1' },
          '50%': { opacity: '0.4' },
        },
        'scan-line': {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100%)' },
        },
        'draw-line': {
          '0%': { strokeDashoffset: '100' },
          '100%': { strokeDashoffset: '0' },
        },
      },
    },
  },
  plugins: [],
};
