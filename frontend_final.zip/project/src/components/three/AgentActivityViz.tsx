import { useRef, useMemo, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// ============ Agent Activity Viz — small background visualization ============

function ActivityParticles() {
  const ref = useRef<THREE.Points>(null);
  const count = 40;
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 6;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 8;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 2;
    }
    return arr;
  }, []);

  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.elapsedTime;
    const pos = ref.current.geometry.attributes.position;
    for (let i = 0; i < count; i++) {
      const y = pos.getY(i);
      pos.setY(i, y + 0.01 + (i % 3) * 0.005);
      if (pos.getY(i) > 4) pos.setY(i, -4);
    }
    pos.needsUpdate = true;
    ref.current.rotation.z = Math.sin(t * 0.1) * 0.02;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color="#2E82F0" size={0.03} transparent opacity={0.4} />
    </points>
  );
}

function FlowLines() {
  const lines = useMemo(() => {
    const arr: THREE.Vector3[][] = [];
    for (let i = 0; i < 6; i++) {
      const pts: THREE.Vector3[] = [];
      for (let j = 0; j < 5; j++) {
        pts.push(new THREE.Vector3((Math.random() - 0.5) * 5, (Math.random() - 0.5) * 8, 0));
      }
      arr.push(pts);
    }
    return arr;
  }, []);

  return (
    <group>
      {lines.map((pts, i) => {
        const geo = new THREE.BufferGeometry().setFromPoints(pts);
        return (
          <primitive key={i} object={new THREE.Line(geo, new THREE.LineBasicMaterial({ color: '#3E4A5A', transparent: true, opacity: 0.08 }))} />
        );
      })}
    </group>
  );
}

export function AgentActivityViz({ className = '' }: { className?: string }) {
  return (
    <div className={className} style={{ position: 'absolute', inset: 0 }}>
      <Canvas
        camera={{ position: [0, 0, 5], fov: 50 }}
        dpr={[1, 1.2]}
        gl={{ antialias: true, alpha: true }}
      >
        <Suspense fallback={null}>
          <FlowLines />
          <ActivityParticles />
        </Suspense>
      </Canvas>
    </div>
  );
}

export default AgentActivityViz;
