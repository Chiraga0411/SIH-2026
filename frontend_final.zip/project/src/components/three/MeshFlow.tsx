import { useRef, useMemo, Suspense, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

// ============ Mesh Flow — computational surface ============

function MeshSurface({ mouseRef }: { mouseRef: React.RefObject<{ x: number; y: number }> }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const geometryRef = useRef<THREE.PlaneGeometry>(null);

  const material = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        color: new THREE.Color('#2E82F0'),
        wireframe: true,
        transparent: true,
        opacity: 0.12,
      }),
    []
  );

  const vertices = useMemo(() => {
    const geo = new THREE.PlaneGeometry(14, 10, 40, 28);
    return geo;
  }, []);

  useFrame((state) => {
    if (!meshRef.current || !geometryRef.current) return;
    const time = state.clock.elapsedTime;
    const pos = geometryRef.current.attributes.position;
    const mouse = mouseRef.current;

    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const distMouse = mouse
        ? Math.sqrt((x - mouse.x * 7) ** 2 + (y - mouse.y * 5) ** 2)
        : 0;
      const wave =
        Math.sin(x * 0.4 + time * 0.3) * 0.3 +
        Math.cos(y * 0.4 + time * 0.2) * 0.3 +
        Math.sin(distMouse * 0.8) * 0.4 * Math.exp(-distMouse * 0.15);
      pos.setZ(i, wave);
    }
    pos.needsUpdate = true;
    meshRef.current.rotation.z = Math.sin(time * 0.05) * 0.02;
  });

  return (
    <mesh ref={meshRef} geometry={vertices} material={material} position={[0, 0, -2]}>
      <planeGeometry ref={geometryRef} args={[14, 10, 40, 28]} />
    </mesh>
  );
}

// ============ Nodes floating in the mesh ============

function FieldNodes({ mouseRef }: { mouseRef: React.RefObject<{ x: number; y: number }> }) {
  const groupRef = useRef<THREE.Group>(null);
  const nodes = useMemo(() => {
    const arr: { pos: [number, number, number]; size: number; speed: number }[] = [];
    for (let i = 0; i < 18; i++) {
      arr.push({
        pos: [
          (Math.random() - 0.5) * 12,
          (Math.random() - 0.5) * 8,
          (Math.random() - 0.5) * 2,
        ],
        size: 0.04 + Math.random() * 0.06,
        speed: 0.5 + Math.random() * 0.5,
      });
    }
    return arr;
  }, []);

  useFrame((state) => {
    if (!groupRef.current) return;
    const time = state.clock.elapsedTime;
    groupRef.current.rotation.y = Math.sin(time * 0.03) * 0.1;
    groupRef.current.children.forEach((child, i) => {
      const node = nodes[i];
      if (!node) return;
      child.position.z = node.pos[2] + Math.sin(time * node.speed + i) * 0.2;
    });
  });

  return (
    <group ref={groupRef}>
      {nodes.map((n, i) => (
        <mesh key={i} position={n.pos}>
          <sphereGeometry args={[n.size, 8, 8]} />
          <meshBasicMaterial color="#2E82F0" transparent opacity={0.6} />
        </mesh>
      ))}
    </group>
  );
}

// ============ Connecting lines ============

function ConnectionLines() {
  const linesRef = useRef<THREE.Group>(null);
  const lines = useMemo(() => {
    const arr: { from: THREE.Vector3; to: THREE.Vector3 }[] = [];
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i < 12; i++) {
      pts.push(
        new THREE.Vector3(
          (Math.random() - 0.5) * 12,
          (Math.random() - 0.5) * 8,
          (Math.random() - 0.5) * 2
        )
      );
    }
    for (let i = 0; i < pts.length - 1; i++) {
      if (Math.random() > 0.4) {
        arr.push({ from: pts[i]!, to: pts[i + 1]! });
      }
    }
    return arr;
  }, []);

  useFrame((state) => {
    if (!linesRef.current) return;
    linesRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 0.02) * 0.01;
  });

  return (
    <group ref={linesRef}>
      {lines.map((l, i) => {
        const geo = new THREE.BufferGeometry().setFromPoints([l.from, l.to]);
        return (
          <primitive key={i} object={new THREE.Line(geo, new THREE.LineBasicMaterial({ color: '#5FA6FF', transparent: true, opacity: 0.15 }))} />
        );
      })}
    </group>
  );
}

// ============ Mouse tracker ============

function MouseTracker({ mouseRef }: { mouseRef: React.MutableRefObject<{ x: number; y: number }> }) {
  const { gl } = useThree();
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      const rect = gl.domElement.getBoundingClientRect();
      mouseRef.current = {
        x: ((e.clientX - rect.left) / rect.width) * 2 - 1,
        y: -((e.clientY - rect.top) / rect.height) * 2 + 1,
      };
    };
    gl.domElement.addEventListener('mousemove', handler);
    return () => gl.domElement.removeEventListener('mousemove', handler);
  }, [gl, mouseRef]);
  return null;
}

// ============ Main MeshFlow Component ============

export function MeshFlow({ className = '', dark = false }: { className?: string; dark?: boolean }) {
  const mouseRef = useRef({ x: 0, y: 0 });

  return (
    <div className={className} style={{ position: 'absolute', inset: 0 }}>
      <Canvas
        camera={{ position: [0, 0, 8], fov: 50 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
        style={{ background: 'transparent' }}
      >
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <MeshSurface mouseRef={mouseRef} />
          <FieldNodes mouseRef={mouseRef} />
          <ConnectionLines />
          <MouseTracker mouseRef={mouseRef} />
        </Suspense>
      </Canvas>
    </div>
  );
}

export default MeshFlow;
