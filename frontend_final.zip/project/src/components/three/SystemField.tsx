import { useRef, useMemo, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// ============ System Field — orbital nodes connected ============

interface FieldNode {
  id: string;
  label: string;
  angle: number;
  radius: number;
  y: number;
  color: string;
}

const systemNodes: FieldNode[] = [
  { id: 'n1', label: 'MODEL ROUTER', angle: 0, radius: 3.5, y: 0.5, color: '#2E82F0' },
  { id: 'n2', label: 'AGENT', angle: Math.PI / 3, radius: 3.5, y: -0.3, color: '#2E82F0' },
  { id: 'n3', label: 'KNOWLEDGE', angle: (2 * Math.PI) / 3, radius: 3.5, y: 0.4, color: '#3FB984' },
  { id: 'n4', label: 'TOOLS', angle: Math.PI, radius: 3.5, y: -0.2, color: '#2E82F0' },
  { id: 'n5', label: 'SANDBOX', angle: (4 * Math.PI) / 3, radius: 3.5, y: 0.6, color: '#F5B544' },
  { id: 'n6', label: 'DELIVERABLES', angle: (5 * Math.PI) / 3, radius: 3.5, y: -0.5, color: '#2E82F0' },
];

function NodeMesh({ node, active }: { node: FieldNode; active: boolean }) {
  const ref = useRef<THREE.Mesh>(null);
  const x = Math.cos(node.angle) * node.radius;
  const z = Math.sin(node.angle) * node.radius;

  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.elapsedTime;
    ref.current.position.y = node.y + Math.sin(t * 0.5 + node.angle) * 0.15;
    ref.current.scale.setScalar(active ? 1.3 : 1);
  });

  return (
    <mesh ref={ref} position={[x, node.y, z]}>
      <sphereGeometry args={[0.12, 12, 12]} />
      <meshBasicMaterial color={node.color} transparent opacity={active ? 0.9 : 0.5} />
    </mesh>
  );
}

function CenterCore({ activeId }: { activeId: string | null }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (!ref.current) return;
    ref.current.rotation.y = state.clock.elapsedTime * 0.2;
    ref.current.scale.setScalar(activeId ? 1.1 : 1);
  });
  return (
    <mesh ref={ref}>
      <icosahedronGeometry args={[0.6, 1]} />
      <meshBasicMaterial color="#2E82F0" wireframe transparent opacity={0.4} />
    </mesh>
  );
}

function ConnectionLines({ activeId }: { activeId: string | null }) {
  const lines = useMemo(() => {
    return systemNodes.map((n) => {
      const from = new THREE.Vector3(0, n.y, 0);
      const to = new THREE.Vector3(Math.cos(n.angle) * n.radius, n.y, Math.sin(n.angle) * n.radius);
      return { id: n.id, from, to, active: activeId === n.id };
    });
  }, [activeId]);

  return (
    <group>
      {lines.map((l) => {
        const geo = new THREE.BufferGeometry().setFromPoints([l.from, l.to]);
        return (
          <primitive key={l.id} object={new THREE.Line(geo, new THREE.LineBasicMaterial({ color: l.active ? '#5FA6FF' : '#3E4A5A', transparent: true, opacity: l.active ? 0.5 : 0.15 }))} />
        );
      })}
    </group>
  );
}

function Scene({ activeId }: { activeId: string | null }) {
  const groupRef = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (!groupRef.current) return;
    groupRef.current.rotation.y = state.clock.elapsedTime * 0.05;
  });

  return (
    <group ref={groupRef}>
      <CenterCore activeId={activeId} />
      <ConnectionLines activeId={activeId} />
      {systemNodes.map((n) => (
        <NodeMesh key={n.id} node={n} active={activeId === n.id} />
      ))}
    </group>
  );
}

export function SystemField({
  activeId = null,
  className = '',
}: {
  activeId?: string | null;
  className?: string;
}) {
  return (
    <div className={className} style={{ position: 'absolute', inset: 0 }}>
      <Canvas
        camera={{ position: [0, 2, 7], fov: 50 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true }}
      >
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <Scene activeId={activeId} />
        </Suspense>
      </Canvas>
    </div>
  );
}

export default SystemField;
