import type { ReactNode } from 'react';
import { useSession } from '@/lib/session';

/**
 * Renders its children (the WebGL scenes) only while "Visual effects" is ON.
 * When OFF it shows the lightweight fallback (a static blueprint grid), so the
 * browser does not compete with the language model for the GPU during a demo.
 */
export function EffectsGate({ children, fallback = null }: { children: ReactNode; fallback?: ReactNode }) {
  const { effectsOn } = useSession();
  return <>{effectsOn ? children : fallback}</>;
}

export default EffectsGate;
