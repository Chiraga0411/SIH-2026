import { useRef, useMemo, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// ============ Sovereignty Visualization ============

// Central core — the sovereign workstation
function SovereignCore() {
  const ref = useRef<THREE.Mesh>(null);
  const ringRef = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (ref.current) ref.current.rotation.y = t * 0.3;
    if (ringRef.current) {
      ringRef.current.rotation.x = t * 0.1;
      ringRef.current.rotation.z = t * 0.15;
    }
  });
  return (
    <group>
      <mesh ref={ref}>
        <icosahedronGeometry args={[0.8, 1]} />
        <meshBasicMaterial color="#2E82F0" wireframe transparent opacity={0.5} />
      </mesh>
      <mesh ref={ringRef}>
        <torusGeometry args={[1.2, 0.015, 8, 64]} />
        <meshBasicMaterial color="#5FA6FF" transparent opacity={0.3} />
      </mesh>
    </group>
  );
}

// Orbiting local service nodes
const orbitNodes = [
  { id: 'model', angle: 0, radius: 2.5, y: 0.5, color: '#2E82F0' },
  { id: 'vector', angle: Math.PI / 3, radius: 2.5, y: -0.6, color: '#3FB984' },
  { id: 'agent', angle: (2 * Math.PI) / 3, radius: 2.5, y: 0.3, color: '#2E82F0' },
  { id: 'sandbox', angle: Math.PI, radius: 2.5, y: -0.4, color: '#F5B544' },
  { id: 'audit', angle: (4 * Math.PI) / 3, radius: 2.5, y: 0.6, color: '#2E82F0' },
  { id: 'docstore', angle: (5 * Math.PI) / 3, radius: 2.5, y: -0.5, color: '#3FB984' },
];

function OrbitNode({ node }: { node: typeof orbitNodes[0] }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.elapsedTime * 0.15;
    const angle = node.angle + t;
    ref.current.position.x = Math.cos(angle) * node.radius;
    ref.current.position.z = Math.sin(angle) * node.radius;
    ref.current.position.y = node.y + Math.sin(t * 2 + node.angle) * 0.2;
  });
  return (
    <mesh ref={ref}>
      <sphereGeometry args={[0.1, 10, 10]} />
      <meshBasicMaterial color={node.color} transparent opacity={0.7} />
    </mesh>
  );
}

// Local boundary sphere
function LocalBoundary() {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (ref.current) ref.current.rotation.y = state.clock.elapsedTime * 0.05;
  });
  return (
    <mesh ref={ref}>
      <sphereGeometry args={[3.2, 24, 24]} />
      <meshBasicMaterial color="#2E82F0" wireframe transparent opacity={0.06} side={THREE.BackSide} />
    </mesh>
  );
}

// Data flow particles (inside local boundary)
function DataFlowParticles() {
  const ref = useRef<THREE.Points>(null);
  const particles = useMemo(() => {
    const count = 60;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = 1 + Math.random() * 2;
      const theta = Math.random() * Math.PI * 2;
      const phi = (Math.random() - 0.5) * Math.PI;
      positions[i * 3] = r * Math.cos(theta) * Math.cos(phi);
      positions[i * 3 + 1] = r * Math.sin(phi);
      positions[i * 3 + 2] = r * Math.sin(theta) * Math.cos(phi);
    }
    return positions;
  }, []);

  useFrame((state) => {
    if (!ref.current) return;
    ref.current.rotation.y = state.clock.elapsedTime * 0.1;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[particles, 3]} />
      </bufferGeometry>
      <pointsMaterial color="#5FA6FF" size={0.04} transparent opacity={0.5} />
    </points>
  );
}

// Blocked external connection attempt
function BlockedAttempt() {
  const ref = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.elapsedTime;
    const cycle = (t % 4) / 4;
    ref.current.children.forEach((child, i) => {
      if (i === 0) {
        child.position.x = 3.2 + cycle * 2;
        child.position.z = -1 + cycle * 0.5;
        const mat = (child as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = cycle < 0.5 ? 0.8 * (1 - cycle * 2) : 0;
      }
    });
  });
  return (
    <group ref={ref}>
      <mesh>
        <sphereGeometry args={[0.08, 8, 8]} />
        <meshBasicMaterial color="#F06565" transparent opacity={0} />
      </mesh>
    </group>
  );
}

function SovereigntyScene() {
  return (
    <group>
      <LocalBoundary />
      <SovereignCore />
      {orbitNodes.map((n) => (
        <OrbitNode key={n.id} node={n} />
      ))}
      <DataFlowParticles />
      <BlockedAttempt />
    </group>
  );
}

export function SovereigntyViz({ className = '' }: { className?: string }) {
  return (
    <div className={className} style={{ position: 'absolute', inset: 0 }}>
      <Canvas
        camera={{ position: [0, 1, 7], fov: 50 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true }}
      >
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <SovereigntyScene />
        </Suspense>
      </Canvas>
    </div>
  );
}

export default SovereigntyViz;
