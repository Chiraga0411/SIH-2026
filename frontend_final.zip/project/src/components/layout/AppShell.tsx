import { type ReactNode, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutGrid, Cpu, BookOpen, Layers, Boxes, TerminalSquare,
  FolderKanban, FileCheck, ShieldCheck, Radar, User,
  ChevronRight, Lock, Wifi, Database, Menu, X, Gauge, ClipboardCheck, Sparkles,
} from 'lucide-react';
import type { ViewId } from '@/data/mockData';
import { useSession } from '@/lib/session';
import { useOnlineStatus } from '@/lib/useOnline';
import { DEMO_MODE } from '@/lib/runtime';

interface NavItem {
  id: ViewId;
  label: string;
  icon: typeof LayoutGrid;
  section: 'main' | 'tools';
}

const navItems: NavItem[] = [
  { id: 'overview', label: 'Overview', icon: LayoutGrid, section: 'main' },
  { id: 'agent', label: 'Agent Workspace', icon: Cpu, section: 'main' },
  { id: 'knowledge', label: 'Knowledge', icon: BookOpen, section: 'main' },
  { id: 'multimodal', label: 'Multimodal', icon: Layers, section: 'main' },
  { id: 'models', label: 'Models', icon: Boxes, section: 'main' },
  { id: 'sandbox', label: 'Sandbox', icon: TerminalSquare, section: 'tools' },
  { id: 'projects', label: 'Projects', icon: FolderKanban, section: 'main' },
  { id: 'deliverables', label: 'Deliverables', icon: FileCheck, section: 'main' },
  { id: 'approval', label: 'Approval Center', icon: ClipboardCheck, section: 'main' },
  { id: 'audit', label: 'Audit', icon: ShieldCheck, section: 'main' },
  { id: 'sovereignty', label: 'Sovereignty', icon: Radar, section: 'main' },
  { id: 'benchmarks', label: 'Benchmarks', icon: Gauge, section: 'main' },
];

function SovereignLogo() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative flex h-8 w-8 items-center justify-center">
        <svg viewBox="0 0 32 32" className="h-8 w-8">
          <rect x="4" y="4" width="24" height="24" fill="none" stroke="#2E82F0" strokeWidth="1" />
          <rect x="8" y="8" width="16" height="16" fill="none" stroke="#2E82F0" strokeWidth="0.5" opacity="0.5" />
          <circle cx="16" cy="16" r="3" fill="none" stroke="#2E82F0" strokeWidth="1" />
          <line x1="16" y1="4" x2="16" y2="13" stroke="#2E82F0" strokeWidth="0.5" />
          <line x1="16" y1="19" x2="16" y2="28" stroke="#2E82F0" strokeWidth="0.5" />
          <line x1="4" y1="16" x2="13" y2="16" stroke="#2E82F0" strokeWidth="0.5" />
          <line x1="19" y1="16" x2="28" y2="16" stroke="#2E82F0" strokeWidth="0.5" />
        </svg>
      </div>
      <div className="leading-none">
        <div className="text-sm font-semibold tracking-tight text-ivory-100">SOVEREIGN AI</div>
        <div className="tech-label text-xs text-graphite-200 mt-0.5">ON-PREM INTELLIGENCE</div>
      </div>
    </div>
  );
}

function NavButton({
  item,
  active,
  onClick,
}: {
  item: NavItem;
  active: boolean;
  onClick: () => void;
}) {
  const Icon = item.icon;
  return (
    <button
      onClick={onClick}
      className={`group relative flex w-full items-center gap-3 px-3 py-2 text-sm transition-colors duration-200 ${
        active ? 'text-ivory-100' : 'text-graphite-200 hover:text-ivory-100'
      }`}
    >
      {active && (
        <motion.div
          layoutId="nav-active"
          className="absolute left-0 top-0 h-full w-0.5 bg-accent-500"
          transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
        />
      )}
      <Icon size={16} className={active ? 'text-accent-400' : 'text-graphite-300 group-hover:text-ivory-100'} />
      <span className="font-medium">{item.label}</span>
      {active && <ChevronRight size={14} className="ml-auto text-accent-400" />}
    </button>
  );
}

function SystemStatusPill({ icon: Icon, label, value, color = 'text-safe-400' }: { icon: typeof Lock; label: string; value: string; color?: string }) {
  return (
    <div className="flex items-center gap-1.5 rounded-md border border-graphite-400/20 bg-graphite-700/50 px-2.5 py-1">
      <Icon size={12} className={color} />
      <span className="tech-label text-xs text-graphite-200">{label}</span>
      <span className={`tech-label text-xs ${color}`}>{value}</span>
    </div>
  );
}

export function Sidebar({
  current,
  onNavigate,
  onLogout,
}: {
  current: ViewId;
  onNavigate: (v: ViewId) => void;
  onLogout: () => void;
}) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { role, username, viewAllowed, effectsOn, setEffectsOn } = useSession();
  const visibleItems = navItems.filter((i) => viewAllowed(i.id));

  const sidebar = (
    <div className="flex h-full flex-col bg-graphite-800">
      <div className="flex items-center justify-between px-4 py-4 hairline-b-dark">
        <SovereignLogo />
        <button className="lg:hidden text-graphite-200" onClick={() => setMobileOpen(false)}>
          <X size={18} />
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto py-4 dark-scroll">
        <div className="px-3 mb-2">
          <div className="tech-label text-xs text-graphite-300 px-3 mb-1.5">NAVIGATION</div>
        </div>
        {visibleItems.filter((i) => i.section === 'main').map((item) => (
          <div key={item.id} className="px-3">
            <NavButton item={item} active={current === item.id} onClick={() => { onNavigate(item.id); setMobileOpen(false); }} />
          </div>
        ))}

        <div className="px-3 mt-4 mb-2">
          <div className="tech-label text-xs text-graphite-300 px-3 mb-1.5">TOOLS</div>
        </div>
        {visibleItems.filter((i) => i.section === 'tools').map((item) => (
          <div key={item.id} className="px-3">
            <NavButton item={item} active={current === item.id} onClick={() => { onNavigate(item.id); setMobileOpen(false); }} />
          </div>
        ))}
      </nav>

      <div className="px-4 py-3 hairline-t-dark space-y-2">
        <button
          type="button"
          onClick={() => setEffectsOn(!effectsOn)}
          className="flex w-full items-center gap-2 text-graphite-200 text-sm hover:text-ivory-100 transition-colors"
          title="3D visuals use the GPU. Turn them off while the language model is running."
        >
          <Sparkles size={16} />
          <span>Visual effects</span>
          <span className={`ml-auto tech-label ${effectsOn ? 'text-accent-400' : 'text-graphite-300'}`}>{effectsOn ? 'ON' : 'OFF'}</span>
        </button>
        <div className="flex items-center gap-2 text-graphite-200 text-sm hover:text-ivory-100 cursor-pointer transition-colors" onClick={onLogout}>
          <User size={16} />
          <div className="flex-1">
            <div className="text-xs font-medium text-ivory-100">{role}</div>
            <div className="tech-label text-xs text-graphite-300 normal-case tracking-normal">{username} · sign out</div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop */}
      <aside className="hidden lg:block w-60 shrink-0 fixed left-0 top-0 h-screen z-30">
        {sidebar}
      </aside>

      {/* Mobile toggle */}
      <button
        className="lg:hidden fixed top-3 left-3 z-40 flex items-center justify-center h-9 w-9 rounded-md panel-dark text-ivory-100"
        onClick={() => setMobileOpen(true)}
      >
        <Menu size={18} />
      </button>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-graphite-900/60 z-40 lg:hidden"
              onClick={() => setMobileOpen(false)}
            />
            <motion.aside
              initial={{ x: -260 }}
              animate={{ x: 0 }}
              exit={{ x: -260 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="fixed left-0 top-0 h-screen w-60 z-50 lg:hidden"
            >
              {sidebar}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

export function TopBar({ title, subtitle }: { title: string; subtitle?: string }) {
  const online = useOnlineStatus();
  return (
    <header className="sticky top-0 z-20 bg-ivory-50/90 backdrop-blur-sm border-b border-ivory-300">
      <div className="flex items-center justify-between px-6 py-3 pl-16 lg:pl-6">
        <div>
          <h1 className="text-base font-semibold text-graphite-700 tracking-tight">{title}</h1>
          {subtitle && <p className="text-xs text-graphite-400 mt-0.5">{subtitle}</p>}
        </div>
        <div className="hidden md:flex items-center gap-2">
          <SystemStatusPill
            icon={Wifi}
            label="NETWORK LINK"
            value={online ? 'ONLINE' : 'OFFLINE'}
            color={online ? 'text-amber-400' : 'text-safe-400'}
          />
          <SystemStatusPill
            icon={Database}
            label="DATA"
            value={DEMO_MODE ? 'DEMO' : 'LIVE'}
            color={DEMO_MODE ? 'text-amber-400' : 'text-safe-400'}
          />
        </div>
      </div>
    </header>
  );
}

export function AppShell({
  current,
  onNavigate,
  onLogout,
  children,
  title,
  subtitle,
}: {
  current: ViewId;
  onNavigate: (v: ViewId) => void;
  onLogout: () => void;
  children: ReactNode;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="min-h-screen bg-ivory-50">
      <Sidebar current={current} onNavigate={onNavigate} onLogout={onLogout} />
      <div className="lg:ml-60">
        <TopBar title={title} subtitle={subtitle} />
        <main className="px-4 md:px-6 py-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
