import { type ReactNode } from 'react';
import { motion } from 'framer-motion';
import {
  CheckCircle2, AlertCircle, Clock, Loader2, XCircle, Activity,
} from 'lucide-react';

type StatusType = 'success' | 'running' | 'pending' | 'warning' | 'error' | 'blocked' | 'idle';

const statusConfig: Record<StatusType, { color: string; bg: string; icon: typeof Activity; label: string }> = {
  success: { color: 'text-safe-500', bg: 'bg-safe-500/10', icon: CheckCircle2, label: 'OK' },
  running: { color: 'text-accent-500', bg: 'bg-accent-500/10', icon: Loader2, label: 'RUNNING' },
  pending: { color: 'text-graphite-300', bg: 'bg-graphite-200/40', icon: Clock, label: 'PENDING' },
  warning: { color: 'text-amber-500', bg: 'bg-amber-400/10', icon: AlertCircle, label: 'WARNING' },
  error: { color: 'text-danger-500', bg: 'bg-danger-500/10', icon: XCircle, label: 'ERROR' },
  blocked: { color: 'text-danger-500', bg: 'bg-danger-500/10', icon: XCircle, label: 'BLOCKED' },
  idle: { color: 'text-steel-400', bg: 'bg-steel-500/10', icon: Activity, label: 'IDLE' },
};

export function StatusIndicator({
  status,
  label,
  size = 'sm',
  animate = false,
}: {
  status: StatusType;
  label?: string;
  size?: 'sm' | 'md';
  animate?: boolean;
}) {
  const cfg = statusConfig[status];
  const Icon = cfg.icon;
  const iconSize = size === 'sm' ? 12 : 14;
  return (
    <span className={`inline-flex items-center gap-1.5 ${cfg.bg} ${cfg.color} rounded px-1.5 py-0.5`}>
      <Icon size={iconSize} className={animate && status === 'running' ? 'animate-spin' : ''} />
      <span className="tech-label text-xs">{label || cfg.label}</span>
    </span>
  );
}

export function TechnicalLabel({
  children,
  className = '',
  accent = false,
}: {
  children: ReactNode;
  className?: string;
  accent?: boolean;
}) {
  return (
    <span className={`tech-label ${accent ? 'text-accent-500' : 'text-graphite-400'} ${className}`}>
      {children}
    </span>
  );
}

export function Badge({
  children,
  variant = 'default',
  className = '',
}: {
  children: ReactNode;
  variant?: 'default' | 'accent' | 'safe' | 'warning' | 'danger' | 'dark';
  className?: string;
}) {
  const variants = {
    default: 'bg-ivory-200 text-graphite-400 border-graphite-200/40',
    accent: 'bg-accent-50 text-accent-600 border-accent-200/50',
    safe: 'bg-safe-500/10 text-safe-600 border-safe-500/20',
    warning: 'bg-amber-400/10 text-amber-600 border-amber-400/20',
    danger: 'bg-danger-500/10 text-danger-500 border-danger-500/20',
    dark: 'bg-graphite-600 text-graphite-100 border-graphite-400/30',
  };
  return (
    <span className={`inline-flex items-center gap-1 rounded border px-2 py-0.5 tech-label text-xs ${variants[variant]} ${className}`}>
      {children}
    </span>
  );
}

export function Button({
  children,
  onClick,
  variant = 'primary',
  size = 'md',
  className = '',
  disabled = false,
  icon,
  type = 'button',
  title,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'dark' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  disabled?: boolean;
  icon?: ReactNode;
  type?: 'button' | 'submit' | 'reset';
  title?: string;
}) {
  const variants = {
    primary: 'bg-accent-500 text-white hover:bg-accent-600 border-accent-500 shadow-sm',
    secondary: 'bg-ivory-50 text-graphite-600 hover:bg-ivory-200 border-graphite-200/60 shadow-sm',
    ghost: 'bg-transparent text-graphite-400 hover:bg-ivory-200 border-transparent',
    dark: 'bg-graphite-600 text-ivory-100 hover:bg-graphite-500 border-graphite-400/30 shadow-sm',
    danger: 'bg-danger-500 text-white hover:bg-danger-600 border-danger-500 shadow-sm',
  };
  const sizes = { sm: 'px-3 py-1.5 text-xs', md: 'px-4 py-2 text-sm', lg: 'px-6 py-3 text-base' };
  return (
    <motion.button
      type={type}
      title={title}
      whileHover={disabled ? {} : { y: -1 }}
      whileTap={disabled ? {} : { y: 0 }}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 rounded-md border font-medium transition-colors duration-200 ease-precision disabled:opacity-50 disabled:cursor-not-allowed ${variants[variant]} ${sizes[size]} ${className}`}
    >
      {icon}
      {children}
    </motion.button>
  );
}

export function Panel({
  children,
  className = '',
  dark = false,
  title,
  label,
  action,
}: {
  children: ReactNode;
  className?: string;
  dark?: boolean;
  title?: string;
  label?: string;
  action?: ReactNode;
}) {
  return (
    <div className={`rounded-xl shadow-panel ${dark ? 'panel-dark' : 'panel-ivory'} ${className}`}>
      {(title || label || action) && (
        <div className={`flex items-center justify-between px-4 py-3 ${dark ? 'hairline-b-dark' : 'hairline-b'}`}>
          <div className="flex items-center gap-2">
            {label && <TechnicalLabel accent={!dark} className={dark ? '!text-accent-300' : ''}>{label}</TechnicalLabel>}
            {title && <span className={`text-sm font-medium ${dark ? 'text-ivory-100' : 'text-graphite-600'}`}>{title}</span>}
          </div>
          {action}
        </div>
      )}
      {children}
    </div>
  );
}

export function Metric({
  label,
  value,
  unit,
  trend,
  accent = false,
  dark = false,
}: {
  label: string;
  value: string | number;
  unit?: string;
  trend?: string;
  accent?: boolean;
  dark?: boolean;
}) {
  return (
    <div className={`rounded-xl border p-4 ${dark ? 'panel-dark' : 'panel-ivory'} transition-all hover:shadow-panel`}>
      <div className={`tech-label ${dark ? 'text-graphite-200' : 'text-graphite-400'} mb-2`}>{label}</div>
      <div className="flex items-baseline gap-1">
        <span className={`text-2xl font-semibold tracking-tight ${accent ? (dark ? 'text-accent-300' : 'text-accent-500') : dark ? 'text-ivory-100' : 'text-graphite-700'}`}>
          {value}
        </span>
        {unit && <span className={`text-xs ${dark ? 'text-graphite-300' : 'text-graphite-400'}`}>{unit}</span>}
      </div>
      {trend && <div className={`mt-1 text-xs ${dark ? 'text-graphite-200' : 'text-graphite-400'}`}>{trend}</div>}
    </div>
  );
}

export function AgentStepCircle({
  label,
  status,
  index,
  active,
}: {
  label: string;
  status: 'pending' | 'active' | 'complete' | 'blocked' | 'awaiting-approval';
  index: number;
  active: boolean;
}) {
  const colors: Record<string, string> = {
    pending: 'border-graphite-200 text-graphite-300 bg-ivory-50',
    active: 'border-accent-500 text-accent-500 bg-accent-50 shadow-accent-glow',
    complete: 'border-safe-500 text-safe-500 bg-safe-500/10',
    blocked: 'border-danger-500 text-danger-500 bg-danger-500/10',
    'awaiting-approval': 'border-amber-500 text-amber-500 bg-amber-400/10',
  };
  return (
    <motion.div
      animate={{ scale: active ? 1.05 : 1 }}
      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
      className={`flex items-center gap-3 rounded-lg border px-3 py-2 ${colors[status]}`}
    >
      <span className="tech-label text-xs opacity-60">{String(index + 1).padStart(2, '0')}</span>
      <span className="text-sm font-medium">{label}</span>
      {active && <motion.span animate={{ opacity: [1, 0.3, 1] }} transition={{ duration: 1.5, repeat: Infinity }} className="ml-auto h-1.5 w-1.5 rounded-full bg-accent-500" />}
      {status === 'complete' && <CheckCircle2 size={14} className="ml-auto" />}
      {status === 'blocked' && <XCircle size={14} className="ml-auto" />}
    </motion.div>
  );
}

export function ApprovalGate({
  onApprove, onReject, onRevision, visible,
}: {
  onApprove: () => void; onReject: () => void; onRevision: () => void; visible: boolean;
}) {
  if (!visible) return null;
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-xl border border-amber-400/40 bg-amber-400/5 p-4">
      <div className="flex items-center gap-2 mb-3">
        <div className="h-2 w-2 rounded-full bg-amber-500 animate-pulse-soft" />
        <span className="tech-label text-amber-600">AGENT READY FOR APPROVAL</span>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="secondary" size="sm" onClick={onRevision}>Request Revision</Button>
        <Button variant="danger" size="sm" onClick={onReject}>Reject</Button>
        <Button variant="primary" size="sm" onClick={onApprove}>Approve</Button>
      </div>
    </motion.div>
  );
}

export function EmptyState({ label, sublabel }: { label: string; sublabel?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="tech-label text-graphite-400 mb-1">{label}</div>
      {sublabel && <div className="text-sm text-graphite-400">{sublabel}</div>}
    </div>
  );
}
