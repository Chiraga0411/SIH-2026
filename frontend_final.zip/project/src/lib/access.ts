/**
 * Role-based access model for the demo UI.
 *
 * Separation of duties:
 *  - Engineer : drafts work, sees Internal documents, cannot approve.
 *  - Manager  : approves deliverables, reads Restricted documents, views audit.
 *  - Admin    : manages models and audit, cannot approve, Internal clearance only.
 *
 * In production these rules must be enforced by the Node gateway (JWT + server
 * checks and retrieval-time filtering). The UI copy here only mirrors them.
 */
export type Role = 'Engineer' | 'Manager' | 'Admin';
export type Clearance = 'Public' | 'Internal' | 'Restricted';
export type Permission = 'approve' | 'addModel' | 'viewAudit' | 'viewApproval';

export const ROLES: Role[] = ['Engineer', 'Manager', 'Admin'];

const PERMISSIONS: Record<Role, Permission[]> = {
  Engineer: [],
  Manager: ['approve', 'viewApproval', 'viewAudit'],
  Admin: ['addModel', 'viewApproval', 'viewAudit'],
};

const CLEARANCE: Record<Role, Clearance> = {
  Engineer: 'Internal',
  Manager: 'Restricted',
  Admin: 'Internal',
};

export const clearanceRank: Record<Clearance, number> = {
  Public: 0,
  Internal: 1,
  Restricted: 2,
};

export function can(role: Role, permission: Permission): boolean {
  return PERMISSIONS[role].includes(permission);
}

export function clearanceFor(role: Role): Clearance {
  return CLEARANCE[role];
}

export function canRead(role: Role, docClearance: Clearance): boolean {
  return clearanceRank[clearanceFor(role)] >= clearanceRank[docClearance];
}

export function defaultUsername(role: Role): string {
  return `${role.toLowerCase()}@demo.local`;
}

/** Which permission (if any) a view needs. */
export function viewPermission(view: string): Permission | null {
  if (view === 'approval') return 'viewApproval';
  if (view === 'audit') return 'viewAudit';
  return null;
}

export function viewAllowed(role: Role, view: string): boolean {
  const need = viewPermission(view);
  return need === null || can(role, need);
}
