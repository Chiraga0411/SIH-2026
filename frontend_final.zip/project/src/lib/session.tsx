import {
  createContext, useCallback, useContext, useMemo, useState, type ReactNode,
} from 'react';
import {
  can as canDo, canRead as canReadDoc, clearanceFor, defaultUsername, viewAllowed as viewOk,
  type Clearance, type Permission, type Role,
} from '@/lib/access';

interface Session {
  role: Role;
  username: string;
  clearance: Clearance;
  signIn: (role: Role, username?: string) => void;
  can: (p: Permission) => boolean;
  canRead: (c: Clearance) => boolean;
  viewAllowed: (view: string) => boolean;
  /** 3D / WebGL visuals on or off (off = static blueprint grid, saves GPU for the LLM). */
  effectsOn: boolean;
  setEffectsOn: (on: boolean) => void;
}

const EFFECTS_KEY = 'sov_effects';

function initialEffects(): boolean {
  try {
    const stored = window.localStorage.getItem(EFFECTS_KEY);
    if (stored === 'on') return true;
    if (stored === 'off') return false;
  } catch {
    /* storage unavailable */
  }
  try {
    return !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch {
    return true;
  }
}

const fallback: Session = {
  role: 'Engineer',
  username: defaultUsername('Engineer'),
  clearance: 'Internal',
  signIn: () => {},
  can: () => false,
  canRead: () => true,
  viewAllowed: () => true,
  effectsOn: true,
  setEffectsOn: () => {},
};

const SessionContext = createContext<Session>(fallback);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>('Engineer');
  const [username, setUsername] = useState<string>(defaultUsername('Engineer'));
  const [effectsOn, setEffectsState] = useState<boolean>(initialEffects);

  const signIn = useCallback((r: Role, u?: string) => {
    setRole(r);
    setUsername(u && u.trim() ? u.trim() : defaultUsername(r));
  }, []);

  const setEffectsOn = useCallback((on: boolean) => {
    setEffectsState(on);
    try {
      window.localStorage.setItem(EFFECTS_KEY, on ? 'on' : 'off');
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<Session>(
    () => ({
      role,
      username,
      clearance: clearanceFor(role),
      signIn,
      can: (p) => canDo(role, p),
      canRead: (c) => canReadDoc(role, c),
      viewAllowed: (v) => viewOk(role, v),
      effectsOn,
      setEffectsOn,
    }),
    [role, username, signIn, effectsOn, setEffectsOn],
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession(): Session {
  return useContext(SessionContext);
}
