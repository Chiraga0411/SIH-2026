/**
 * Runtime configuration.
 *
 * DEMO_MODE is true while no backend URL is configured. In demo mode every
 * dashboard value (connection counters, audit events, jobs...) is synthetic
 * sample data, and the UI says so. Set VITE_API_BASE (see .env.example) when
 * your Node/FastAPI backend is running to switch the badges to LIVE.
 */
export const API_BASE: string = (import.meta.env.VITE_API_BASE as string | undefined) ?? '';
export const DEMO_MODE: boolean = API_BASE === '';
