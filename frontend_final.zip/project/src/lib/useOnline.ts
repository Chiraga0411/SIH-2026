import { useEffect, useState } from 'react';

/**
 * Real, browser-reported network link state (navigator.onLine).
 * It only says whether the device has a network link, not whether traffic
 * leaves the building, so pair it with Wireshark / the backend monitor for proof.
 */
export function useOnlineStatus(): boolean {
  const [online, setOnline] = useState<boolean>(
    typeof navigator === 'undefined' ? true : navigator.onLine,
  );

  useEffect(() => {
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    window.addEventListener('online', up);
    window.addEventListener('offline', down);
    return () => {
      window.removeEventListener('online', up);
      window.removeEventListener('offline', down);
    };
  }, []);

  return online;
}
