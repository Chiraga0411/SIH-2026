import { useState, lazy, Suspense, useEffect } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import type { ViewId } from '@/data/mockData';
import Lenis from 'lenis';
import { Lock } from 'lucide-react';
import { SessionProvider, useSession } from '@/lib/session';
import type { Role } from '@/lib/access';
import { Panel } from '@/components/ui/primitives';

// Lazy load all views for code splitting
const LoginView = lazy(() => import('@/views/LoginView'));
const OverviewView = lazy(() => import('@/views/OverviewView'));
const AgentWorkspaceView = lazy(() => import('@/views/AgentWorkspaceView'));
const KnowledgeView = lazy(() => import('@/views/KnowledgeView'));
const MultimodalView = lazy(() => import('@/views/MultimodalView'));
const ModelsView = lazy(() => import('@/views/ModelsView'));
const SandboxView = lazy(() => import('@/views/SandboxView'));
const SovereigntyView = lazy(() => import('@/views/SovereigntyView'));
const AuditView = lazy(() => import('@/views/AuditView'));
const DeliverablesView = lazy(() => import('@/views/DeliverablesView'));
const ApprovalView = lazy(() => import('@/views/ApprovalView'));
const ProjectsView = lazy(() => import('@/views/ProjectsView'));
const BenchmarksView = lazy(() => import('@/views/BenchmarksView'));

const viewMeta: Record<ViewId, { title: string; subtitle: string }> = {
  overview: { title: 'Overview', subtitle: 'Engineering operations dashboard' },
  agent: { title: 'Agent Workspace', subtitle: 'Agentic task execution and live trace' },
  knowledge: { title: 'Knowledge Base', subtitle: 'Document intelligence and grounded retrieval' },
  multimodal: { title: 'Multimodal Intelligence', subtitle: 'Document processing and OCR pipeline' },
  models: { title: 'Model Router', subtitle: 'Local model registry and task routing' },
  sandbox: { title: 'Sandbox', subtitle: 'Isolated code execution environment' },
  projects: { title: 'Projects', subtitle: 'Engineering project workspaces' },
  deliverables: { title: 'Deliverables', subtitle: 'Generated artifacts and approvals' },
  approval: { title: 'Approval Center', subtitle: 'Human-in-the-loop deliverable review' },
  audit: { title: 'Audit Log', subtitle: 'Hash-chained integrity verification' },
  sovereignty: { title: 'Sovereignty Monitor', subtitle: 'Air-gapped operation and network security' },
  benchmarks: { title: 'Benchmarks', subtitle: 'Measured performance on this hardware' },
};

function LoadingFallback() {
  return (
    <div className="flex items-center justify-center py-20">
      <div className="flex items-center gap-2 text-graphite-300">
        <div className="h-4 w-4 border-2 border-accent-500 border-t-transparent rounded-full animate-spin" />
        <span className="tech-label text-xs">LOADING</span>
      </div>
    </div>
  );
}

function AccessDenied({ title }: { title: string }) {
  const { role } = useSession();
  return (
    <Panel label="ACCESS CONTROL" title="Restricted view">
      <div className="flex flex-col items-center gap-3 px-6 py-14 text-center">
        <Lock size={28} className="text-graphite-400" />
        <div className="text-base font-semibold text-graphite-700">{title} is not available to the {role} role</div>
        <div className="max-w-md text-sm text-graphite-400">
          Access is decided by role. In production the Node gateway enforces this on every request, and the denied attempt is written to the audit log.
        </div>
      </div>
    </Panel>
  );
}

function AppInner() {
  const { signIn, viewAllowed } = useSession();
  const [loggedIn, setLoggedIn] = useState(false);
  const [current, setCurrent] = useState<ViewId>('overview');

  // Smooth scrolling with Lenis
  useEffect(() => {
    if (!loggedIn) return;
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) return;

    const lenis = new Lenis({
      duration: 1.2,
      easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
    });

    let raf = 0;
    const loop = (time: number) => {
      lenis.raf(time);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      lenis.destroy();
    };
  }, [loggedIn]);

  if (!loggedIn) {
    return (
      <Suspense fallback={<LoadingFallback />}>
        <LoginView onLogin={(r: Role, u: string) => { signIn(r, u); setCurrent('overview'); setLoggedIn(true); }} />
      </Suspense>
    );
  }

  const meta = viewMeta[current];

  const renderView = () => {
    if (!viewAllowed(current)) return <AccessDenied title={meta.title} />;
    switch (current) {
      case 'overview': return <OverviewView onNavigate={(v) => setCurrent(v as ViewId)} />;
      case 'agent': return <AgentWorkspaceView />;
      case 'knowledge': return <KnowledgeView />;
      case 'multimodal': return <MultimodalView />;
      case 'models': return <ModelsView />;
      case 'sandbox': return <SandboxView />;
      case 'projects': return <ProjectsView onNavigate={(v) => setCurrent(v as ViewId)} />;
      case 'deliverables': return <DeliverablesView onNavigate={(v) => setCurrent(v as ViewId)} />;
      case 'approval': return <ApprovalView />;
      case 'audit': return <AuditView />;
      case 'sovereignty': return <SovereigntyView />;
      case 'benchmarks': return <BenchmarksView />;
      default: return <OverviewView onNavigate={(v) => setCurrent(v as ViewId)} />;
    }
  };

  return (
    <AppShell
      current={current}
      onNavigate={setCurrent}
      onLogout={() => setLoggedIn(false)}
      title={meta.title}
      subtitle={meta.subtitle}
    >
      <Suspense fallback={<LoadingFallback />}>
        {renderView()}
      </Suspense>
    </AppShell>
  );
}

export default function App() {
  return (
    <SessionProvider>
      <AppInner />
    </SessionProvider>
  );
}
