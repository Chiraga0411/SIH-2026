// NOTE: everything in this file is synthetic SAMPLE DATA for the UI prototype.
// Replace model names/sizes with the Ollama tags and numbers you actually measured,
// and replace these arrays with API calls once the backend exists.
import { buildChain, type AuditCore } from '@/lib/hashChain';
import type { Clearance } from '@/lib/access';

// ============ TYPES ============

export type ViewId =
  | 'overview'
  | 'agent'
  | 'knowledge'
  | 'multimodal'
  | 'models'
  | 'sandbox'
  | 'projects'
  | 'deliverables'
  | 'approval'
  | 'audit'
  | 'sovereignty'
  | 'benchmarks';

export type AgentStage = 'PLAN' | 'ACT' | 'OBSERVE' | 'VERIFY' | 'REVISE' | 'DELIVER';
export type StageStatus = 'pending' | 'active' | 'complete' | 'blocked' | 'awaiting-approval';

export type TraceCategory =
  | 'MODEL ROUTER' | 'TOOL CALL' | 'KB SEARCH' | 'OCR'
  | 'CALCULATION' | 'SANDBOX' | 'VERIFICATION' | 'DELIVERABLE' | 'NETWORK';

export interface TraceEvent {
  id: string;
  time: string;
  category: TraceCategory;
  action: string;
  status: 'success' | 'running' | 'blocked' | 'warning';
  duration: string;
  source: string;
  result: string;
}

export interface ModelInfo {
  id: string;
  name: string;
  type: string;
  context: string;
  capabilities: string[];
  gpuMem: string;
  status: 'loaded' | 'standby' | 'loading';
  tasks: string[];
  tasksSupported: string[];
}

export interface DocItem {
  id: string;
  name: string;
  type: 'PDF' | 'DOCX' | 'XLSX' | 'Image' | 'Drawing' | 'Note';
  size: string;
  date: string;
  pages?: number;
  status: 'indexed' | 'processing' | 'queued';
  source: string;
  confidence?: number;
  clearance: Clearance;
  flag?: 'injection';
}

export interface AuditEntry extends AuditCore {
  hash: string;
  prevHash: string;
  status: 'verified' | 'pending';
}

export interface JobItem {
  id: string;
  name: string;
  project: string;
  status: 'RUNNING' | 'WAITING FOR APPROVAL' | 'QUEUED' | 'COMPLETED' | 'BLOCKED';
  progress: number;
  agent: string;
  startedAt: string;
}

export interface Deliverable {
  id: string;
  name: string;
  type: 'Word' | 'PowerPoint' | 'Excel' | 'Code' | 'Calculation' | 'Report';
  task: string;
  source: string;
  verification: 'verified' | 'pending' | 'failed';
  version: string;
  approval: 'approved' | 'pending' | 'rejected';
  author: string;
  date: string;
  size: string;
}

export interface ProjectInfo {
  id: string;
  code: string;
  name: string;
  description: string;
  documents: number;
  agents: number;
  tasks: number;
  models: number;
  deliverables: number;
  auditEvents: number;
  status: 'active' | 'archived';
}

export interface LocalService {
  id: string;
  name: string;
  status: 'operational' | 'degraded' | 'offline';
  uptime: string;
  connections: number;
  description: string;
}

export interface ConnectionEvent {
  id: string;
  time: string;
  type: 'blocked' | 'allowed-local' | 'denied-egress';
  source: string;
  destination: string;
  protocol: string;
  result: string;
}

export interface FileNode {
  id: string;
  name: string;
  type: 'folder' | 'file';
  children?: FileNode[];
  fileType?: string;
}

// ============ MOCK DATA ============

export const projects: ProjectInfo[] = [
  {
    id: 'p1',
    code: 'DEMO-IA-2026',
    name: 'Inspection Analysis (Sample)',
    description: 'Analysis of boiler inspection reports, generation of approval notes, and verification of compliance with engineering standards.',
    documents: 14,
    agents: 3,
    tasks: 7,
    models: 4,
    deliverables: 5,
    auditEvents: 142,
    status: 'active',
  },
  {
    id: 'p2',
    code: 'DEMO-PID-2026',
    name: 'P&ID Extraction (Sample)',
    description: 'Extraction of structured data from P&ID engineering drawings using multimodal vision models and cross-referencing with equipment registries.',
    documents: 8,
    agents: 2,
    tasks: 4,
    models: 3,
    deliverables: 2,
    auditEvents: 67,
    status: 'active',
  },
  {
    id: 'p3',
    code: 'DEMO-CALC-2026',
    name: 'Structural Calculation Review (Sample)',
    description: 'Automated verification of structural load calculations against IS code provisions with sandboxed computation and human approval gates.',
    documents: 11,
    agents: 2,
    tasks: 5,
    models: 3,
    deliverables: 3,
    auditEvents: 89,
    status: 'active',
  },
  {
    id: 'p4',
    code: 'DEMO-DOC-2025',
    name: 'Document Compliance Audit (Sample)',
    description: 'Bulk compliance audit of historical engineering documents, SOPs, and inspection correspondence against updated regulatory framework.',
    documents: 42,
    agents: 1,
    tasks: 3,
    models: 2,
    deliverables: 8,
    auditEvents: 256,
    status: 'archived',
  },
];

export const fileTree: FileNode[] = [
  {
    id: 'f1', name: 'DEMO-IA-2026', type: 'folder', children: [
      {
        id: 'f2', name: 'Inspection Reports', type: 'folder', children: [
          { id: 'f3', name: 'Boiler-3_Inspection_2026.pdf', type: 'file', fileType: 'PDF' },
          { id: 'f4', name: 'Boiler-3_Inspection_2025.pdf', type: 'file', fileType: 'PDF' },
          { id: 'f5', name: 'Site_Photos_Boiler3.zip', type: 'file', fileType: 'Image' },
        ]
      },
      {
        id: 'f6', name: 'Engineering Drawings', type: 'folder', children: [
          { id: 'f7', name: 'Boiler-3_PID_v4.dwg', type: 'file', fileType: 'Drawing' },
          { id: 'f8', name: 'Boiler-3_Schematic.pdf', type: 'file', fileType: 'PDF' },
        ]
      },
      {
        id: 'f9', name: 'SOPs', type: 'folder', children: [
          { id: 'f10', name: 'Inspection_SOP_Rev3.docx', type: 'file', fileType: 'DOCX' },
          { id: 'f11', name: 'Approval_Workflow_SOP.docx', type: 'file', fileType: 'DOCX' },
        ]
      },
      {
        id: 'f12', name: 'Knowledge Sources', type: 'folder', children: [
          { id: 'f13', name: 'Sample_Boiler_Code.pdf', type: 'file', fileType: 'PDF' },
          { id: 'f14', name: 'Sample_Structural_Code.pdf', type: 'file', fileType: 'PDF' },
          { id: 'f15', name: 'Past_Approval_Notes.zip', type: 'file', fileType: 'PDF' },
        ]
      },
    ]
  }
];

export const agentStages: { stage: AgentStage; label: string; description: string }[] = [
  { stage: 'PLAN', label: 'Plan', description: 'Decompose task into executable steps' },
  { stage: 'ACT', label: 'Act', description: 'Execute tool calls and model inference' },
  { stage: 'OBSERVE', label: 'Observe', description: 'Collect results from tool execution' },
  { stage: 'VERIFY', label: 'Verify', description: 'Cross-check findings against knowledge base' },
  { stage: 'REVISE', label: 'Revise', description: 'Refine output based on verification' },
  { stage: 'DELIVER', label: 'Deliver', description: 'Generate final deliverable for approval' },
];

export const initialTrace: TraceEvent[] = [
  { id: 't1', time: '09:14:22.014', category: 'MODEL ROUTER', action: 'Route: document reasoning', status: 'success', duration: '12ms', source: 'Router', result: '→ General-8B' },
  { id: 't2', time: '09:14:22.026', category: 'OCR', action: 'Process Boiler-3_Inspection_2026.pdf', status: 'success', duration: '3.4s', source: 'Vision-VL', result: '24 pages, 187 regions extracted' },
  { id: 't3', time: '09:14:25.431', category: 'KB SEARCH', action: 'Search Sample Boiler Code cl. 4', status: 'success', duration: '340ms', source: 'Vector DB', result: '7 relevant passages, 0.91 confidence' },
  { id: 't4', time: '09:14:25.771', category: 'TOOL CALL', action: 'Cross-reference inspection findings', status: 'success', duration: '1.2s', source: 'Reasoning tool', result: '4 compliance items flagged' },
  { id: 't5', time: '09:14:26.974', category: 'CALCULATION', action: 'Wall thickness verification', status: 'success', duration: '85ms', source: 'Sandbox', result: 'Calculation passed, margin 1.8mm' },
  { id: 't6', time: '09:14:27.059', category: 'SANDBOX', action: 'python wall_thickness_calc.py', status: 'success', duration: '120ms', source: 'Sandbox', result: 'Exit code 0, verification passed' },
  { id: 't7', time: '09:14:27.179', category: 'NETWORK', action: 'Outbound request attempt', status: 'blocked', duration: '1ms', source: 'Egress filter', result: 'OUTBOUND REQUEST BLOCKED — DENIED' },
  { id: 't8', time: '09:14:27.180', category: 'VERIFICATION', action: 'Grounding check against 3 sources', status: 'success', duration: '210ms', source: 'Verifier', result: 'Source verified, 3 documents, 7 passages' },
  { id: 't9', time: '09:14:27.391', category: 'DELIVERABLE', action: 'Generate approval note (Word)', status: 'running', duration: '—', source: 'Deliverable service', result: 'Drafting approval note...' },
];

export const models: ModelInfo[] = [
  {
    id: 'm1', name: 'General-8B', type: 'Language', context: '8K tokens',
    capabilities: ['Document reasoning', 'Planning', 'Summarization'],
    gpuMem: '~5 GB (Q4)', status: 'loaded',
    tasks: ['document-reasoning', 'planning'],
    tasksSupported: ['DOCUMENT REASONING', 'PLANNING', 'SUMMARIZATION'],
  },
  {
    id: 'm2', name: 'Coder-7B', type: 'Code', context: '8K tokens',
    capabilities: ['Python', 'Calculations', 'Script generation'],
    gpuMem: '~4.5 GB (Q4)', status: 'standby',
    tasks: ['code', 'calculation'],
    tasksSupported: ['CODE', 'CALCULATION', 'SQL'],
  },
  {
    id: 'm3', name: 'Vision-VL', type: 'Multimodal Vision', context: '4K tokens',
    capabilities: ['OCR', 'Handwriting', 'Drawing tags', 'Photo description'],
    gpuMem: '~4 GB (Q4)', status: 'standby',
    tasks: ['vision', 'ocr'],
    tasksSupported: ['VISION', 'OCR', 'DRAWING ANALYSIS'],
  },
  {
    id: 'm4', name: 'Embed-Small', type: 'Embedding', context: '8K tokens',
    capabilities: ['Semantic search', 'RAG retrieval'],
    gpuMem: '< 1 GB', status: 'loaded',
    tasks: ['embedding'],
    tasksSupported: ['EMBEDDING', 'SEMANTIC SEARCH'],
  },
  {
    id: 'm5', name: 'Router-3B', type: 'Language', context: '4K tokens',
    capabilities: ['Task classification', 'Light reasoning', 'Labeling'],
    gpuMem: '~2 GB (Q4)', status: 'standby',
    tasks: [],
    tasksSupported: ['CLASSIFICATION', 'LABELING'],
  },
];

export const documents: DocItem[] = [
  { id: 'd1', name: 'Boiler-3 Inspection Report 2026', type: 'PDF', size: '4.2 MB', date: '2026-09-15', pages: 24, status: 'indexed', source: 'Site Inspection', confidence: 0.94, clearance: 'Internal' },
  { id: 'd2', name: 'Sample Boiler Code', type: 'PDF', size: '12.8 MB', date: '2024-03-10', pages: 186, status: 'indexed', source: 'Regulatory Reference', confidence: 0.99, clearance: 'Public' },
  { id: 'd3', name: 'Inspection SOP Rev 3', type: 'DOCX', size: '890 KB', date: '2025-11-20', pages: 14, status: 'indexed', source: 'Engineering Procedures', confidence: 0.97, clearance: 'Internal' },
  { id: 'd4', name: 'Boiler-3 P&ID v4', type: 'Drawing', size: '2.1 MB', date: '2025-08-14', status: 'indexed', source: 'Engineering Drawings', confidence: 0.88, clearance: 'Restricted' },
  { id: 'd5', name: 'Site Photos Boiler-3', type: 'Image', size: '18.4 MB', date: '2026-09-14', status: 'indexed', source: 'Site Visit', confidence: 0.82, clearance: 'Internal' },
  { id: 'd6', name: 'Past Approval Notes 2024', type: 'PDF', size: '6.7 MB', date: '2024-12-03', pages: 42, status: 'indexed', source: 'Historical Archive', confidence: 0.93, clearance: 'Restricted' },
  { id: 'd7', name: 'Handwritten Field Notes Sept', type: 'Note', size: '1.2 MB', date: '2026-09-13', pages: 8, status: 'processing', source: 'Field Engineer', confidence: 0.71, clearance: 'Internal' },
  { id: 'd8', name: 'Sample Structural Code', type: 'PDF', size: '9.3 MB', date: '2023-06-15', pages: 98, status: 'indexed', source: 'Regulatory Reference', confidence: 0.98, clearance: 'Public' },
  { id: 'd9', name: 'Vendor_Letter_Scan.pdf', type: 'PDF', size: '310 KB', date: '2026-09-20', pages: 2, status: 'indexed', source: 'External Correspondence', confidence: 0.9, clearance: 'Internal', flag: 'injection' },
];

/** Clearance of a document looked up by name (used to filter citations). */
export function clearanceOfDocument(name: string): Clearance {
  return documents.find((d) => d.name === name)?.clearance ?? 'Internal';
}

const rawAuditEntries: AuditCore[] = [
  { id: 'a0b', time: '2026-09-20 09:16:02.410', user: 'system', action: 'INJECTION_FLAGGED', resource: 'Vendor_Letter_Scan.pdf', model: 'General-8B', result: 'QUARANTINED' },
  { id: 'a0a', time: '2026-09-20 09:15:10.005', user: 'engineer@demo.local', action: 'ACCESS_DENIED', resource: 'Boiler-3 P&ID v4 (Restricted)', model: '—', result: 'DENIED' },
  { id: 'a1', time: '2026-09-20 09:14:27.391', user: 'engineer@demo.local', action: 'DELIVERABLE_GENERATED', resource: 'Approval_Note_Boiler3.docx', model: 'General-8B', result: 'SUCCESS' },
  { id: 'a2', time: '2026-09-20 09:14:27.180', user: 'system', action: 'EGRESS_BLOCKED', resource: 'external-api.example.com:443', model: '—', result: 'DENIED' },
  { id: 'a3', time: '2026-09-20 09:14:22.026', user: 'system', action: 'OCR_PROCESSED', resource: 'Boiler-3_Inspection_2026.pdf', model: 'Vision-VL', result: 'SUCCESS' },
  { id: 'a4', time: '2026-09-20 09:14:22.014', user: 'engineer@demo.local', action: 'MODEL_ROUTED', resource: 'document-reasoning → General-8B', model: 'Router', result: 'SUCCESS' },
  { id: 'a5', time: '2026-09-20 09:12:01.340', user: 'engineer@demo.local', action: 'TASK_INITIATED', resource: 'Analyze inspection report → approval note', model: '—', result: 'QUEUED' },
  { id: 'a6', time: '2026-09-20 09:08:44.120', user: 'manager@demo.local', action: 'DELIVERABLE_APPROVED', resource: 'Compliance_Report_Rev2.docx', model: 'General-8B', result: 'APPROVED' },
  { id: 'a7', time: '2026-09-20 08:52:17.003', user: 'engineer@demo.local', action: 'DOCUMENT_UPLOADED', resource: 'Handwritten_Field_Notes.pdf', model: '—', result: 'INDEXED' },
  { id: 'a8', time: '2026-09-19 17:31:08.220', user: 'admin@demo.local', action: 'MODEL_LOADED', resource: 'Vision-VL', model: '—', result: 'LOADED' },
  { id: 'a9', time: '2026-09-19 16:14:52.880', user: 'manager@demo.local', action: 'TASK_REVISION_REQUESTED', resource: 'P&ID_Extraction_Draft.xlsx', model: 'Vision-VL', result: 'REVISION REQUESTED' },
  { id: 'a10', time: '2026-09-19 15:02:33.110', user: 'engineer@demo.local', action: 'SANDBOX_EXECUTED', resource: 'wall_thickness_calc.py', model: 'Coder-7B', result: 'SUCCESS' },
];

/** Newest first. Hashes are computed with SHA-256 (see lib/hashChain.ts), not typed by hand. */
export const auditEntries: AuditEntry[] = buildChain(rawAuditEntries).map((e) => ({ ...e, status: 'verified' as const }));

export const jobs: JobItem[] = [
  { id: 'j1', name: 'Inspection Report Analysis', project: 'DEMO-IA-2026', status: 'RUNNING', progress: 78, agent: 'Inspector Agent', startedAt: '09:12:01' },
  { id: 'j2', name: 'Approval Note Generation', project: 'DEMO-IA-2026', status: 'WAITING FOR APPROVAL', progress: 100, agent: 'Inspector Agent', startedAt: '09:14:27' },
  { id: 'j3', name: 'P&ID Tag Extraction', project: 'DEMO-PID-2026', status: 'QUEUED', progress: 0, agent: 'Drawing Agent', startedAt: '—' },
  { id: 'j4', name: 'Structural Calc Verification', project: 'DEMO-CALC-2026', status: 'RUNNING', progress: 45, agent: 'Calc Agent', startedAt: '09:08:30' },
  { id: 'j5', name: 'Code Verification Batch', project: 'DEMO-CALC-2026', status: 'COMPLETED', progress: 100, agent: 'Calc Agent', startedAt: '08:42:00' },
  { id: 'j7', name: 'Retrieval Accuracy Check', project: 'DEMO-DOC-2025', status: 'QUEUED', progress: 0, agent: 'Audit Agent', startedAt: '—' },
  { id: 'j6', name: 'SOP Compliance Scan', project: 'DEMO-DOC-2025', status: 'BLOCKED', progress: 34, agent: 'Audit Agent', startedAt: '08:15:00' },
];

export const deliverables: Deliverable[] = [
  { id: 'dl1', name: 'Approval_Note_Boiler3.docx', type: 'Word', task: 'Inspection report analysis', source: 'Boiler-3 Inspection Report 2026', verification: 'verified', version: 'v1.0', approval: 'pending', author: 'Inspector Agent', date: '2026-09-20', size: '142 KB' },
  { id: 'dl2', name: 'Compliance_Report_Rev2.docx', type: 'Word', task: 'Compliance verification', source: 'Sample Boiler Code', verification: 'verified', version: 'v2.0', approval: 'approved', author: 'Inspector Agent', date: '2026-09-20', size: '218 KB' },
  { id: 'dl3', name: 'Wall_Thickness_Calc.xlsx', type: 'Excel', task: 'Wall thickness verification', source: 'Boiler-3 P&ID v4', verification: 'verified', version: 'v1.0', approval: 'approved', author: 'Calc Agent', date: '2026-09-19', size: '56 KB' },
  { id: 'dl4', name: 'Inspection_Summary.pptx', type: 'PowerPoint', task: 'Inspection summary deck', source: 'Boiler-3 Inspection Report 2026', verification: 'pending', version: 'v1.0-draft', approval: 'pending', author: 'Inspector Agent', date: '2026-09-20', size: '1.8 MB' },
  { id: 'dl5', name: 'wall_thickness_calc.py', type: 'Code', task: 'Wall thickness calculation', source: 'Coder-7B', verification: 'verified', version: 'v1.2', approval: 'approved', author: 'Calc Agent', date: '2026-09-19', size: '8.4 KB' },
  { id: 'dl6', name: 'PID_Tag_Extract.xlsx', type: 'Excel', task: 'P&ID tag extraction', source: 'Boiler-3 P&ID v4', verification: 'pending', version: 'v0.3-draft', approval: 'rejected', author: 'Drawing Agent', date: '2026-09-19', size: '124 KB' },
];

export const localServices: LocalService[] = [
  { id: 's1', name: 'Model Server', status: 'operational', uptime: '14d 6h', connections: 4, description: 'Local inference server hosting all AI models' },
  { id: 's2', name: 'Vector Database', status: 'operational', uptime: '14d 6h', connections: 2, description: 'Embedded knowledge base and semantic search index' },
  { id: 's3', name: 'Agent Service', status: 'operational', uptime: '14d 6h', connections: 3, description: 'Agentic execution loop and task orchestration' },
  { id: 's4', name: 'Sandbox', status: 'operational', uptime: '14d 6h', connections: 1, description: 'Isolated code execution with no network egress' },
  { id: 's5', name: 'Audit Service', status: 'operational', uptime: '14d 6h', connections: 1, description: 'Hash-chained audit log and integrity verification' },
  { id: 's6', name: 'Document Store', status: 'operational', uptime: '14d 6h', connections: 2, description: 'Local encrypted document storage and processing' },
];

export const connectionEvents: ConnectionEvent[] = [
  { id: 'c1', time: '09:14:27', type: 'denied-egress', source: 'Sandbox', destination: 'external-api.example.com:443', protocol: 'HTTPS', result: 'BLOCKED — Egress policy: DENY_ALL' },
  { id: 'c2', time: '09:12:01', type: 'allowed-local', source: 'Agent Service', destination: 'Model Server (localhost:8080)', protocol: 'gRPC', result: 'ALLOWED — Local inference' },
  { id: 'c3', time: '09:08:30', type: 'allowed-local', source: 'Calc Agent', destination: 'Sandbox (localhost:9090)', protocol: 'WebSocket', result: 'ALLOWED — Local execution' },
  { id: 'c4', time: '08:52:17', type: 'allowed-local', source: 'Document Store', destination: 'Vector DB (localhost:6332)', protocol: 'HTTP', result: 'ALLOWED — Local indexing' },
  { id: 'c5', time: '08:15:00', type: 'denied-egress', source: 'Audit Agent', destination: 'updates.software.com:443', protocol: 'HTTPS', result: 'BLOCKED — Egress policy: DENY_ALL' },
];

// Agent execution plan steps
export const planSteps = [
  { id: 'ps1', label: 'Parse inspection report (PDF)', tool: 'OCR + Vision', model: 'Vision-VL' },
  { id: 'ps2', label: 'Extract inspection findings and measurements', tool: 'Reasoning', model: 'General-8B' },
  { id: 'ps3', label: 'Retrieve relevant sample-code passages', tool: 'KB Search', model: 'Embed-Small' },
  { id: 'ps4', label: 'Verify wall thickness calculation', tool: 'Sandbox', model: 'Coder-7B' },
  { id: 'ps5', label: 'Cross-reference findings with past approvals', tool: 'KB Search', model: 'General-8B' },
  { id: 'ps6', label: 'Generate structured approval note', tool: 'Deliverable', model: 'General-8B' },
];

// Document OCR regions mock
export const ocrRegions = [
  { id: 'r1', label: 'Header: Boiler-3 Annual Inspection', x: 8, y: 6, w: 84, h: 8, confidence: 0.98 },
  { id: 'r2', label: 'Date: 2026-09-12', x: 8, y: 16, w: 30, h: 5, confidence: 0.96 },
  { id: 'r3', label: 'Wall Thickness Reading: 6.2mm', x: 10, y: 28, w: 60, h: 6, confidence: 0.93 },
  { id: 'r4', label: 'Min Required: 4.4mm (Sample Code cl. 4.2)', x: 10, y: 36, w: 65, h: 6, confidence: 0.91 },
  { id: 'r5', label: 'Inspector Signature (handwritten)', x: 50, y: 72, w: 40, h: 12, confidence: 0.74 },
  { id: 'r6', label: 'Condition: ACCEPTABLE — margin 1.8mm', x: 10, y: 44, w: 75, h: 6, confidence: 0.95 },
];

export const routingExamples = [
  { task: 'DOCUMENT REASONING', model: 'General-8B', reason: 'General instruct model: best at multi-page reading, planning and summarisation; stays resident in GPU memory' },
  { task: 'CODE', model: 'Coder-7B', reason: 'Code-tuned model for Python and calculations; swapped in only when a coding task arrives, to save VRAM' },
  { task: 'VISION', model: 'Vision-VL', reason: 'Small vision-language model for handwriting, photos and drawing regions; loaded on demand after OCR' },
  { task: 'EMBEDDING', model: 'Embed-Small', reason: 'Dedicated small embedding model for semantic search; tiny footprint so it stays loaded' },
];


// ============ WORKSPACES / COLLABORATION (sample) ============

export interface ProjectMember {
  name: string;
  email: string;
  role: 'Engineer' | 'Manager' | 'Admin';
}

export interface ActivityItem {
  id: string;
  time: string;
  user: string;
  action: string;
  visibility: 'Shared' | 'Private';
}

const eng = (n: string, e: string): ProjectMember => ({ name: n, email: e, role: 'Engineer' });

export const projectMembers: Record<string, ProjectMember[]> = {
  p1: [
    eng('Engineer A', 'engineer@demo.local'),
    eng('Engineer B', 'engineer.b@demo.local'),
    { name: 'Manager A', email: 'manager@demo.local', role: 'Manager' },
    { name: 'Admin A', email: 'admin@demo.local', role: 'Admin' },
  ],
  p2: [
    eng('Engineer B', 'engineer.b@demo.local'),
    { name: 'Manager A', email: 'manager@demo.local', role: 'Manager' },
  ],
  p3: [
    eng('Engineer A', 'engineer@demo.local'),
    { name: 'Manager A', email: 'manager@demo.local', role: 'Manager' },
  ],
  p4: [{ name: 'Admin A', email: 'admin@demo.local', role: 'Admin' }],
};

export const projectActivity: Record<string, ActivityItem[]> = {
  p1: [
    { id: 'x1', time: '09:14', user: 'engineer@demo.local', action: 'Generated approval note draft (Approval_Note_Boiler3.docx)', visibility: 'Shared' },
    { id: 'x2', time: '09:08', user: 'manager@demo.local', action: 'Approved Compliance_Report_Rev2.docx', visibility: 'Shared' },
    { id: 'x3', time: '08:52', user: 'engineer.b@demo.local', action: 'Private scratch analysis of field notes', visibility: 'Private' },
    { id: 'x4', time: '08:40', user: 'engineer@demo.local', action: 'Private experiment: alternative wall-thickness formulation', visibility: 'Private' },
    { id: 'x5', time: '08:15', user: 'admin@demo.local', action: 'Added Coder-7B to the model registry', visibility: 'Shared' },
  ],
  p2: [
    { id: 'y1', time: '09:01', user: 'engineer.b@demo.local', action: 'Queued P&ID tag extraction', visibility: 'Shared' },
    { id: 'y2', time: '08:30', user: 'manager@demo.local', action: 'Requested revision of PID_Tag_Extract.xlsx', visibility: 'Shared' },
  ],
  p3: [
    { id: 'z1', time: '09:08', user: 'engineer@demo.local', action: 'Started structural calc verification', visibility: 'Shared' },
    { id: 'z2', time: '08:42', user: 'engineer@demo.local', action: 'Code verification batch completed', visibility: 'Shared' },
  ],
  p4: [
    { id: 'w1', time: '08:15', user: 'admin@demo.local', action: 'SOP compliance scan blocked (needs review)', visibility: 'Shared' },
  ],
};
