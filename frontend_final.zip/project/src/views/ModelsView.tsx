import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Cpu, Plus, Box, Zap, Server, ArrowRight, CheckCircle2, Activity, Lock,
} from 'lucide-react';
import { Panel, TechnicalLabel, Badge, StatusIndicator, Button } from '@/components/ui/primitives';
import { models, routingExamples, type ModelInfo } from '@/data/mockData';
import { useSession } from '@/lib/session';

const typeDefaults: Record<string, { type: string; caps: string[]; tasks: string[] }> = {
  Language: { type: 'Language', caps: ['Document reasoning', 'Summarization'], tasks: ['DOCUMENT REASONING', 'SUMMARIZATION'] },
  Vision: { type: 'Multimodal Vision', caps: ['OCR', 'Image understanding'], tasks: ['VISION', 'OCR'] },
  Code: { type: 'Code', caps: ['Code generation', 'Calculations'], tasks: ['CODE', 'CALCULATION'] },
  Embedding: { type: 'Embedding', caps: ['Semantic search'], tasks: ['EMBEDDING'] },
};

function ModelCard({ model, onClick, active }: { model: ModelInfo; onClick: () => void; active: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`text-left rounded-xl border p-4 transition-all ${
        active ? 'border-accent-500/60 bg-accent-50 shadow-panel' : 'panel-ivory hover:shadow-panel hover:border-ivory-300'
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${active ? 'bg-accent-500/10' : 'bg-ivory-200'}`}>
            <Cpu size={16} className={active ? 'text-accent-500' : 'text-graphite-400'} />
          </div>
          <div>
            <div className="text-sm font-semibold text-graphite-700">{model.name}</div>
            <div className="tech-label text-xs text-graphite-400 mt-0.5">{model.type}</div>
          </div>
        </div>
        <StatusIndicator status={model.status === 'loaded' ? 'success' : model.status === 'standby' ? 'warning' : 'running'} label={model.status.toUpperCase()} />
      </div>

      <div className="grid grid-cols-2 gap-2 mb-3">
        <div>
          <div className="tech-label text-xs text-graphite-400">CONTEXT</div>
          <div className="text-xs text-graphite-600 mt-0.5">{model.context}</div>
        </div>
        <div>
          <div className="tech-label text-xs text-graphite-400">GPU MEMORY</div>
          <div className="text-xs text-graphite-600 mt-0.5">{model.gpuMem}</div>
        </div>
      </div>

      <div className="flex flex-wrap gap-1">
        {model.capabilities.map((c) => (
          <span key={c} className="rounded bg-ivory-200 px-1.5 py-0.5 tech-label text-xs text-graphite-400">{c}</span>
        ))}
      </div>
    </button>
  );
}

export function ModelsView() {
  const { can } = useSession();
  const canAdd = can('addModel');
  const [modelList, setModelList] = useState<ModelInfo[]>(models);
  const [selectedModel, setSelectedModel] = useState<ModelInfo>(models[0]);
  const [showAddModel, setShowAddModel] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPath, setNewPath] = useState('');
  const [newType, setNewType] = useState('Language');
  const [newMem, setNewMem] = useState('');
  const [notice, setNotice] = useState<string | null>(null);

  // Demo: registers the model in memory only. In production the router reads the
  // registry from a config file / database, so a new entry needs no code change.
  const installModel = () => {
    const name = newName.trim();
    if (!name) return;
    const d = typeDefaults[newType] ?? typeDefaults.Language;
    const model: ModelInfo = {
      id: `m-${Date.now()}`,
      name,
      type: d.type,
      context: '—',
      capabilities: d.caps,
      gpuMem: newMem.trim() || '—',
      status: 'standby',
      tasks: [],
      tasksSupported: d.tasks,
    };
    setModelList((prev) => [...prev, model]);
    setSelectedModel(model);
    setNotice(`${name} registered. The router can select it now, with no code change and no restart.`);
    window.setTimeout(() => setNotice(null), 7000);
    setNewName('');
    setNewPath('');
    setNewMem('');
    setNewType('Language');
    setShowAddModel(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">MODEL INTELLIGENCE / LOCAL INFERENCE</TechnicalLabel>
          <h2 className="text-editorial-sm text-graphite-700">Model Router</h2>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="safe">LOCAL ONLY</Badge>
          <Badge variant="safe">NO EXTERNAL API</Badge>
          <Badge variant="accent">MODEL REGISTRY ACTIVE</Badge>
        </div>
      </div>

      {notice && (
        <div className="flex items-center gap-2 rounded-lg border border-safe-500/30 bg-safe-500/5 px-4 py-2.5 text-sm text-graphite-600">
          <CheckCircle2 size={16} className="shrink-0 text-safe-500" />
          {notice}
        </div>
      )}

      {/* Model cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {modelList.map((m) => (
          <ModelCard key={m.id} model={m} onClick={() => setSelectedModel(m)} active={selectedModel.id === m.id} />
        ))}
        {/* Add Model card (Admin only) */}
        {!canAdd && (
          <div className="flex min-h-[180px] flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-ivory-300 p-4 text-center text-graphite-400">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-ivory-200">
              <Lock size={16} />
            </div>
            <span className="text-sm font-medium">Add Model</span>
            <span className="tech-label text-xs">ADMIN ROLE REQUIRED</span>
          </div>
        )}
        {canAdd && <button
          onClick={() => setShowAddModel(true)}
          className="rounded-xl border-2 border-dashed border-ivory-300 p-4 flex flex-col items-center justify-center gap-2 text-graphite-400 hover:border-accent-300 hover:text-accent-500 transition-colors min-h-[180px]"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-ivory-200">
            <Plus size={16} />
          </div>
          <span className="text-sm font-medium">Add Model</span>
          <span className="tech-label text-xs">INSTALL LOCAL MODEL</span>
        </button>}
      </div>

      {/* Routing graph */}
      <Panel label="TASK ROUTING" title="Model Selection Graph" action={
        <StatusIndicator status="success" label="ROUTING ACTIVE" />
      }>
        <div className="p-6">
          <div className="flex items-center justify-between gap-4 overflow-x-auto">
            {/* Input */}
            <div className="shrink-0 flex flex-col items-center gap-2">
              <div className="rounded-lg border border-ivory-300 bg-ivory-50 p-3 w-32 text-center">
                <Activity size={16} className="text-graphite-400 mx-auto mb-1" />
                <div className="tech-label text-xs text-graphite-400">USER TASK</div>
              </div>
            </div>

            {/* Arrow */}
            <ArrowRight size={16} className="text-graphite-400 shrink-0" />

            {/* Router */}
            <div className="shrink-0 flex flex-col items-center gap-2">
              <div className="rounded-lg border border-accent-500/40 bg-accent-50 p-3 w-32 text-center shadow-accent-glow">
                <Zap size={16} className="text-accent-500 mx-auto mb-1" />
                <div className="tech-label text-xs text-accent-500">ROUTER</div>
                <div className="text-xs text-graphite-400 mt-0.5">Evaluates task</div>
              </div>
            </div>

            {/* Arrows to models */}
            <div className="shrink-0 flex flex-col gap-1">
              {[0, 1, 2].map(i => <ArrowRight key={i} size={12} className="text-graphite-400" />)}
            </div>

            {/* Models */}
            <div className="shrink-0 flex flex-col gap-1">
              {modelList.slice(0, 3).map((m) => (
                <div key={m.id} className={`rounded-lg border p-2 w-40 ${selectedModel.id === m.id ? 'border-accent-500/40 bg-accent-50' : 'border-ivory-300 bg-ivory-50'}`}>
                  <div className="text-xs font-medium text-graphite-600 truncate">{m.name}</div>
                  <div className="tech-label text-xs text-graphite-400">{m.type}</div>
                </div>
              ))}
            </div>

            {/* Arrow */}
            <ArrowRight size={16} className="text-graphite-400 shrink-0" />

            {/* Output */}
            <div className="shrink-0 flex flex-col items-center gap-2">
              <div className="rounded-lg border border-safe-500/40 bg-safe-500/5 p-3 w-32 text-center">
                <CheckCircle2 size={16} className="text-safe-500 mx-auto mb-1" />
                <div className="tech-label text-xs text-safe-600">RESULT</div>
                <div className="text-xs text-graphite-400 mt-0.5">Local output</div>
              </div>
            </div>
          </div>
        </div>
      </Panel>

      {/* Routing examples */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel label="WHY THIS MODEL?" title="Routing Explanation">
          <div className="p-4 space-y-3">
            {routingExamples.map((r) => (
              <div key={r.task} className={`rounded-lg border p-3 transition-colors ${selectedModel.name === r.model ? 'border-accent-200/50 bg-accent-50' : 'border-ivory-300'}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="tech-label text-xs text-graphite-400">{r.task}</span>
                  <ArrowRight size={10} className="text-graphite-400" />
                  <span className="tech-label text-xs text-accent-500">{r.model}</span>
                </div>
                <div className="text-xs text-graphite-500">{r.reason}</div>
              </div>
            ))}
          </div>
        </Panel>

        <Panel label="SELECTED MODEL" title={selectedModel.name} action={<Badge variant="accent">DETAILS</Badge>}>
          <div className="p-4 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="tech-label text-xs text-graphite-400">TYPE</div>
                <div className="text-sm text-graphite-600 mt-0.5">{selectedModel.type}</div>
              </div>
              <div>
                <div className="tech-label text-xs text-graphite-400">CONTEXT WINDOW</div>
                <div className="text-sm text-graphite-600 mt-0.5">{selectedModel.context}</div>
              </div>
              <div>
                <div className="tech-label text-xs text-graphite-400">GPU MEMORY</div>
                <div className="text-sm text-graphite-600 mt-0.5">{selectedModel.gpuMem}</div>
              </div>
              <div>
                <div className="tech-label text-xs text-graphite-400">STATUS</div>
                <div className="mt-0.5"><StatusIndicator status={selectedModel.status === 'loaded' ? 'success' : 'warning'} label={selectedModel.status.toUpperCase()} /></div>
              </div>
            </div>
            <div>
              <div className="tech-label text-xs text-graphite-400 mb-1.5">CAPABILITIES</div>
              <div className="flex flex-wrap gap-1.5">
                {selectedModel.capabilities.map((c) => <Badge key={c} variant="default">{c}</Badge>)}
              </div>
            </div>
            <div>
              <div className="tech-label text-xs text-graphite-400 mb-1.5">TASKS SUPPORTED</div>
              <div className="flex flex-wrap gap-1.5">
                {selectedModel.tasksSupported.map((t) => <Badge key={t} variant="accent">{t}</Badge>)}
              </div>
            </div>
          </div>
        </Panel>
      </div>

      {/* Add Model modal */}
      <AnimatePresence>
        {showAddModel && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-graphite-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowAddModel(false)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              onClick={(e) => e.stopPropagation()}
              className="panel-ivory rounded-xl p-6 max-w-md w-full shadow-panel-lg"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent-50">
                  <Box size={18} className="text-accent-500" />
                </div>
                <div>
                  <div className="text-base font-semibold text-graphite-700">Install Local Model</div>
                  <div className="tech-label text-xs text-graphite-400">ADD TO MODEL REGISTRY</div>
                </div>
              </div>
              <div className="space-y-3">
                <div>
                  <label className="tech-label text-xs text-graphite-400 block mb-1.5">MODEL NAME</label>
                  <input className="w-full rounded-md border border-ivory-300 bg-ivory-50 px-3 py-2 text-sm outline-none focus:border-accent-300" placeholder="Coder-14B" value={newName} onChange={(e) => setNewName(e.target.value)} />
                </div>
                <div>
                  <label className="tech-label text-xs text-graphite-400 block mb-1.5">MODEL FILE PATH</label>
                  <input className="w-full rounded-md border border-ivory-300 bg-ivory-50 px-3 py-2 text-sm outline-none focus:border-accent-300 font-mono" placeholder="/models/coder-14b.gguf" value={newPath} onChange={(e) => setNewPath(e.target.value)} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="tech-label text-xs text-graphite-400 block mb-1.5">TYPE</label>
                    <select value={newType} onChange={(e) => setNewType(e.target.value)} className="w-full rounded-md border border-ivory-300 bg-ivory-50 px-3 py-2 text-sm outline-none focus:border-accent-300">
                      <option>Language</option><option>Vision</option><option>Code</option><option>Embedding</option>
                    </select>
                  </div>
                  <div>
                    <label className="tech-label text-xs text-graphite-400 block mb-1.5">GPU MEMORY</label>
                    <input className="w-full rounded-md border border-ivory-300 bg-ivory-50 px-3 py-2 text-sm outline-none focus:border-accent-300" placeholder="5 GB" value={newMem} onChange={(e) => setNewMem(e.target.value)} />
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 mt-5">
                <Button variant="ghost" size="sm" onClick={() => setShowAddModel(false)}>Cancel</Button>
                <Button variant="primary" size="sm" icon={<Server size={14} />} onClick={installModel} disabled={!newName.trim()}>Install Model</Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default ModelsView;
