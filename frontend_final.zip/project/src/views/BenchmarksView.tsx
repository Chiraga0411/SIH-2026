import { useState } from 'react';
import { Copy, Trash2, Beaker } from 'lucide-react';
import { Panel, TechnicalLabel, Badge, Button } from '@/components/ui/primitives';
import { models } from '@/data/mockData';

/**
 * Benchmarks: a place to record what you actually MEASURED on your demo hardware
 * (tokens/second, load time, task time, retrieval accuracy). The charts and the
 * text summary update from the numbers you type, and the summary can be pasted
 * into the report and the PPT. Nothing is fabricated: the page starts empty.
 * "Load sample values" fills illustrative numbers only to preview the layout.
 */

interface SpeedRow { id: string; name: string; tps: string; load: string; vram: string }
interface TaskRow { id: string; name: string; manual: string; assisted: string }
interface Retrieval { total: string; baseline: string; hybrid: string }
interface Hardware { gpu: string; vram: string; ram: string; os: string }
interface BenchState { hardware: Hardware; speed: SpeedRow[]; tasks: TaskRow[]; retrieval: Retrieval; external: string }

const emptyState = (): BenchState => ({
  hardware: { gpu: '', vram: '', ram: '', os: '' },
  speed: models.map((m) => ({ id: m.id, name: m.name, tps: '', load: '', vram: '' })),
  tasks: [
    { id: 'k1', name: 'Scan to approval note', manual: '', assisted: '' },
    { id: 'k2', name: 'Engineering calculation with steps', manual: '', assisted: '' },
    { id: 'k3', name: 'Code + test in sandbox', manual: '', assisted: '' },
  ],
  retrieval: { total: '', baseline: '', hybrid: '' },
  external: '',
});

/** Illustrative numbers ONLY to preview the layout. Replace with real measurements. */
const sampleState = (): BenchState => {
  const s = emptyState();
  const tps = ['34', '38', '18', '210', '55'];
  const load = ['6.5', '5.8', '7.2', '1.1', '2.4'];
  const vram = ['5.0', '4.5', '4.0', '0.6', '2.0'];
  s.hardware = { gpu: 'Sample GPU', vram: '6 GB', ram: '16 GB', os: 'Windows 11' };
  s.speed = s.speed.map((r, i) => ({ ...r, tps: tps[i] ?? '', load: load[i] ?? '', vram: vram[i] ?? '' }));
  s.tasks = [
    { ...s.tasks[0], manual: '40', assisted: '9' },
    { ...s.tasks[1], manual: '25', assisted: '6' },
    { ...s.tasks[2], manual: '30', assisted: '8' },
  ];
  s.retrieval = { total: '15', baseline: '9', hybrid: '13' };
  s.external = '0';
  return s;
};

const num = (s: string): number | null => {
  const v = parseFloat(s);
  return Number.isFinite(v) && v >= 0 ? v : null;
};

const inputCls =
  'w-full rounded-md border border-ivory-300 bg-ivory-50 px-3 py-2 text-sm text-graphite-600 outline-none focus:border-accent-300';

function Field({
  label, value, onChange, placeholder,
}: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <label className="block">
      <span className="tech-label text-xs text-graphite-400 mb-1 block">{label}</span>
      <input
        className={inputCls}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

function Bar({ value, max, tone = 'accent' }: { value: number | null; max: number; tone?: 'accent' | 'muted' }) {
  const pct = value === null || max <= 0 ? 0 : Math.min(100, Math.round((value / max) * 100));
  return (
    <div className="h-2 w-full rounded bg-ivory-200">
      <div
        className={`h-2 rounded ${tone === 'accent' ? 'bg-accent-500' : 'bg-graphite-200'}`}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

export function BenchmarksView() {
  const [state, setState] = useState<BenchState>(emptyState);
  const [sample, setSample] = useState(false);
  const [copied, setCopied] = useState<'idle' | 'ok' | 'fail'>('idle');

  const setHardware = (k: keyof Hardware, v: string) =>
    setState((s) => ({ ...s, hardware: { ...s.hardware, [k]: v } }));
  const setSpeed = (id: string, k: 'tps' | 'load' | 'vram', v: string) =>
    setState((s) => ({ ...s, speed: s.speed.map((r) => (r.id === id ? { ...r, [k]: v } : r)) }));
  const setTask = (id: string, k: 'manual' | 'assisted', v: string) =>
    setState((s) => ({ ...s, tasks: s.tasks.map((r) => (r.id === id ? { ...r, [k]: v } : r)) }));
  const setRetrieval = (k: keyof Retrieval, v: string) =>
    setState((s) => ({ ...s, retrieval: { ...s.retrieval, [k]: v } }));

  const maxTps = Math.max(1, ...state.speed.map((r) => num(r.tps) ?? 0));
  const maxTask = Math.max(1, ...state.tasks.flatMap((t) => [num(t.manual) ?? 0, num(t.assisted) ?? 0]));

  const total = num(state.retrieval.total);
  const pctOf = (hits: string): number | null => {
    const h = num(hits);
    return total && total > 0 && h !== null && h <= total ? Math.round((h / total) * 100) : null;
  };
  const baselinePct = pctOf(state.retrieval.baseline);
  const hybridPct = pctOf(state.retrieval.hybrid);

  const saving = (t: TaskRow): number | null => {
    const m = num(t.manual);
    const a = num(t.assisted);
    return m !== null && m > 0 && a !== null ? Math.round((1 - a / m) * 100) : null;
  };

  const summary = (() => {
    const h = state.hardware;
    const lines: string[] = [];
    lines.push(sample ? 'SAMPLE VALUES (not measured)' : 'Measured on prototype, sample data');
    lines.push(`Hardware: ${h.gpu || '-'} | VRAM ${h.vram || '-'} | RAM ${h.ram || '-'} | ${h.os || '-'}`);
    lines.push('');
    lines.push('Model speed (tokens/s | load s | VRAM GB):');
    state.speed.forEach((r) => lines.push(`- ${r.name}: ${r.tps || '-'} | ${r.load || '-'} | ${r.vram || '-'}`));
    lines.push('');
    lines.push('Task time, manual vs assisted (minutes):');
    state.tasks.forEach((t) => {
      const sv = saving(t);
      lines.push(`- ${t.name}: ${t.manual || '-'} -> ${t.assisted || '-'}${sv !== null ? ` (${sv}% less time)` : ''}`);
    });
    lines.push('');
    lines.push(
      `Retrieval, correct source in top-3 (${state.retrieval.total || '-'} questions): plain vector ${
        baselinePct === null ? '-' : `${baselinePct}%`
      } | hybrid + reranker ${hybridPct === null ? '-' : `${hybridPct}%`}`,
    );
    lines.push(`External connections observed during a full task (Wi-Fi off): ${state.external || '-'}`);
    return lines.join('\n');
  })();

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(summary);
      setCopied('ok');
    } catch {
      setCopied('fail');
    }
    window.setTimeout(() => setCopied('idle'), 2500);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">BENCHMARKS / MEASURED ON THIS HARDWARE</TechnicalLabel>
          <h2 className="text-editorial-sm text-graphite-700">Benchmarks</h2>
          <p className="mt-1 max-w-2xl text-sm text-graphite-400">
            Type the numbers you measured on your demo machine. The charts and the summary update automatically, so the
            same figures go into the report and the PPT. Use synthetic or public sample documents only.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {sample ? <Badge variant="warning">SAMPLE VALUES — NOT MEASURED</Badge> : <Badge variant="default">YOUR MEASUREMENTS</Badge>}
          <Button
            variant="secondary"
            size="sm"
            icon={<Beaker size={14} />}
            onClick={() => { setState(sampleState()); setSample(true); }}
          >
            Load sample values (preview)
          </Button>
          <Button
            variant="ghost"
            size="sm"
            icon={<Trash2 size={14} />}
            onClick={() => { setState(emptyState()); setSample(false); }}
          >
            Clear all
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-8 space-y-4">
          <Panel label="HARDWARE" title="Demo machine">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-4">
              <Field label="GPU" value={state.hardware.gpu} onChange={(v) => setHardware('gpu', v)} placeholder="e.g. RTX 4050 Laptop" />
              <Field label="VRAM" value={state.hardware.vram} onChange={(v) => setHardware('vram', v)} placeholder="e.g. 6 GB" />
              <Field label="RAM" value={state.hardware.ram} onChange={(v) => setHardware('ram', v)} placeholder="e.g. 16 GB" />
              <Field label="OS" value={state.hardware.os} onChange={(v) => setHardware('os', v)} placeholder="e.g. Windows 11" />
            </div>
          </Panel>

          <Panel label="MODEL SPEED" title="Tokens per second, load time, VRAM">
            <div className="p-4 space-y-3">
              <p className="text-xs text-graphite-400">
                Get tokens/s from the model runtime's verbose output, VRAM from <span className="font-mono">nvidia-smi</span>, and
                load time by timing the first request after switching models.
              </p>
              {state.speed.map((r) => (
                <div key={r.id} className="grid grid-cols-12 items-end gap-3">
                  <div className="col-span-12 md:col-span-3 text-sm font-medium text-graphite-600">{r.name}</div>
                  <div className="col-span-4 md:col-span-2">
                    <Field label="TOKENS/S" value={r.tps} onChange={(v) => setSpeed(r.id, 'tps', v)} />
                  </div>
                  <div className="col-span-4 md:col-span-2">
                    <Field label="LOAD (S)" value={r.load} onChange={(v) => setSpeed(r.id, 'load', v)} />
                  </div>
                  <div className="col-span-4 md:col-span-2">
                    <Field label="VRAM (GB)" value={r.vram} onChange={(v) => setSpeed(r.id, 'vram', v)} />
                  </div>
                  <div className="col-span-12 md:col-span-3 pb-3">
                    <Bar value={num(r.tps)} max={maxTps} />
                  </div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel label="TASK TIME" title="Manual vs with the workbench (minutes)">
            <div className="p-4 space-y-4">
              <p className="text-xs text-graphite-400">
                Have a teammate do each task by hand with a timer, then with the workbench, using the same sample data.
              </p>
              {state.tasks.map((t) => {
                const sv = saving(t);
                return (
                  <div key={t.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-graphite-600">{t.name}</span>
                      {sv !== null && <Badge variant="safe">{sv}% LESS TIME</Badge>}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Field label="MANUAL (MIN)" value={t.manual} onChange={(v) => setTask(t.id, 'manual', v)} />
                        <Bar value={num(t.manual)} max={maxTask} tone="muted" />
                      </div>
                      <div className="space-y-1.5">
                        <Field label="WITH WORKBENCH (MIN)" value={t.assisted} onChange={(v) => setTask(t.id, 'assisted', v)} />
                        <Bar value={num(t.assisted)} max={maxTask} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Panel>

          <Panel label="RETRIEVAL" title="Is the right source in the top 3 results?">
            <div className="p-4 space-y-4">
              <p className="text-xs text-graphite-400">
                Write about 15 test questions whose answer you know. Count how often the correct document is in the top 3 results.
              </p>
              <div className="grid grid-cols-3 gap-3">
                <Field label="QUESTIONS ASKED" value={state.retrieval.total} onChange={(v) => setRetrieval('total', v)} />
                <Field label="CORRECT: PLAIN VECTOR" value={state.retrieval.baseline} onChange={(v) => setRetrieval('baseline', v)} />
                <Field label="CORRECT: HYBRID + RERANK" value={state.retrieval.hybrid} onChange={(v) => setRetrieval('hybrid', v)} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs text-graphite-400">
                    <span>Plain vector</span>
                    <span>{baselinePct === null ? '—' : `${baselinePct}%`}</span>
                  </div>
                  <Bar value={baselinePct} max={100} tone="muted" />
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs text-graphite-400">
                    <span>Hybrid + reranker</span>
                    <span>{hybridPct === null ? '—' : `${hybridPct}%`}</span>
                  </div>
                  <Bar value={hybridPct} max={100} />
                </div>
              </div>
            </div>
          </Panel>

          <Panel label="SOVEREIGNTY" title="External connections during a full task">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-4">
              <Field
                label="OBSERVED IN WIRESHARK / MONITOR"
                value={state.external}
                onChange={(v) => setState((s) => ({ ...s, external: v }))}
                placeholder="Wi-Fi off, full task"
              />
              <p className="md:col-span-2 text-xs text-graphite-400 self-end pb-2">
                Enter the count you actually saw with Wi-Fi off during a full run (scan to Word note). Keep the capture as a screenshot for the PPT.
              </p>
            </div>
          </Panel>
        </div>

        <div className="lg:col-span-4">
          <Panel
            label="SUMMARY"
            title="Copy into report / PPT"
            action={
              <Button variant="primary" size="sm" icon={<Copy size={14} />} onClick={copy}>
                {copied === 'ok' ? 'Copied' : copied === 'fail' ? 'Copy failed' : 'Copy'}
              </Button>
            }
          >
            <div className="p-4">
              <pre className="whitespace-pre-wrap break-words rounded-lg bg-ivory-100 p-3 font-mono text-xs leading-relaxed text-graphite-500">
                {summary}
              </pre>
              {copied === 'fail' && (
                <p className="mt-2 text-xs text-amber-600">
                  The browser blocked copying (common on plain http). Select the text above and copy it manually.
                </p>
              )}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

export default BenchmarksView;
