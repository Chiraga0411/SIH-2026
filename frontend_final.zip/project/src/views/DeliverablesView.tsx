import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  FileText,
  FileType,
  FileSpreadsheet,
  FileCode,
  Presentation,
  Calculator,
  Eye,
  Download,
} from 'lucide-react';
import { TechnicalLabel, Badge, Button } from '@/components/ui/primitives';
import { deliverables } from '@/data/mockData';

const typeIcons: Record<string, typeof FileText> = {
  Word: FileType,
  PowerPoint: Presentation,
  Excel: FileSpreadsheet,
  Code: FileCode,
  Calculation: Calculator,
  Report: FileText,
};

export function DeliverablesView({ onNavigate }: { onNavigate: (v: string) => void }) {
  const [filter, setFilter] = useState<string>('ALL');
  const types = ['ALL', 'Word', 'PowerPoint', 'Excel', 'Code', 'Calculation', 'Report'];
  const filtered = filter === 'ALL' ? deliverables : deliverables.filter(d => d.type === filter);

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">DELIVERABLES / GENERATED ARTIFACTS</TechnicalLabel>
          <h2 className="text-editorial-sm text-graphite-700">Deliverables</h2>
        </div>
        <Button variant="secondary" size="sm" onClick={() => onNavigate('approval')}>Go to Approval Center</Button>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        {types.map((t) => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            className={`rounded-md border px-2.5 py-1 tech-label text-xs transition-colors ${
              filter === t ? 'border-accent-500/60 bg-accent-50 text-accent-600' : 'border-ivory-300 bg-ivory-50 text-graphite-400 hover:text-graphite-500'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Deliverable cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map((d) => {
          const Icon = typeIcons[d.type] || FileText;
          return (
            <motion.div
              key={d.id}
              layout
              className="rounded-xl panel-ivory p-4 hover:shadow-panel transition-all"
            >
              {/* File preview */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex h-12 w-10 items-center justify-center rounded-md bg-ivory-200 border border-ivory-300">
                  <Icon size={20} className="text-graphite-400" />
                </div>
                <div className="flex flex-col items-end gap-1">
                  <Badge variant={d.approval === 'approved' ? 'safe' : d.approval === 'rejected' ? 'danger' : 'warning'}>
                    {d.approval.toUpperCase()}
                  </Badge>
                  <Badge variant={d.verification === 'verified' ? 'safe' : d.verification === 'failed' ? 'danger' : 'warning'}>
                    {d.verification.toUpperCase()}
                  </Badge>
                </div>
              </div>

              <div className="text-sm font-medium text-graphite-700 truncate mb-1">{d.name}</div>
              <div className="text-xs text-graphite-400 mb-3">{d.task}</div>

              <div className="space-y-1.5 mb-3">
                <div className="flex items-center justify-between">
                  <span className="tech-label text-xs text-graphite-400">CREATED BY</span>
                  <span className="text-xs text-graphite-500">{d.author}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="tech-label text-xs text-graphite-400">SOURCE</span>
                  <span className="text-xs text-graphite-500 truncate max-w-[150px]">{d.source}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="tech-label text-xs text-graphite-400">VERSION</span>
                  <span className="text-xs text-graphite-500 font-mono">{d.version}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="tech-label text-xs text-graphite-400">DATE</span>
                  <span className="text-xs text-graphite-500">{d.date}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="tech-label text-xs text-graphite-400">SIZE</span>
                  <span className="text-xs text-graphite-500">{d.size}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 hairline-t pt-3">
                <Button variant="ghost" size="sm" icon={<Eye size={12} />}>Preview</Button>
                <Button variant="ghost" size="sm" icon={<Download size={12} />}>Download</Button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

export default DeliverablesView;
