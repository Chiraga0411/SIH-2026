import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Upload, FileText, ScanLine, CheckCircle2, Eye, Layers,
  Type, Grid3x3, AlertTriangle,
} from 'lucide-react';
import { Panel, TechnicalLabel, Badge } from '@/components/ui/primitives';
import { ocrRegions } from '@/data/mockData';

const pipelineStages = [
  { id: 'upload', label: 'UPLOAD', icon: Upload, desc: 'Document received' },
  { id: 'ocr', label: 'OCR / VISION', icon: ScanLine, desc: 'Text and layout extraction' },
  { id: 'structure', label: 'STRUCTURE', icon: Grid3x3, desc: 'Document structure identified' },
  { id: 'extract', label: 'EXTRACT', icon: Type, desc: 'Entities and data extracted' },
  { id: 'crosscheck', label: 'CROSS-CHECK', icon: Layers, desc: 'Verified against knowledge base' },
  { id: 'analyze', label: 'ANALYZE', icon: Eye, desc: 'Contextual analysis' },
  { id: 'deliver', label: 'DELIVER', icon: CheckCircle2, desc: 'Structured output ready' },
];

const docTypes = [
  { type: 'Scanned PDF', status: 'processed', count: 4 },
  { type: 'Handwritten Notes', status: 'processed', count: 2 },
  { type: 'Engineering Drawings', status: 'processed', count: 3 },
  { type: 'Photographs', status: 'processed', count: 8 },
  { type: 'Technical Documents', status: 'processed', count: 11 },
];

export function MultimodalView() {
  const [activeStage, setActiveStage] = useState('ocr');
  const [selectedRegion, setSelectedRegion] = useState<string | null>('r3');

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">MULTIMODAL DOCUMENT INTELLIGENCE</TechnicalLabel>
          <h2 className="text-editorial-sm text-graphite-700">Document Processing</h2>
        </div>
        <Badge variant="accent">VISION MODEL · VISION-VL</Badge>
      </div>

      {/* Pipeline */}
      <Panel label="PROCESSING PIPELINE" title="Document Intelligence Flow">
        <div className="p-4">
          <div className="flex items-center gap-1 overflow-x-auto pb-2">
            {pipelineStages.map((s, i) => {
              const Icon = s.icon;
              const isActive = s.id === activeStage;
              const isPast = pipelineStages.findIndex(p => p.id === activeStage) > i;
              return (
                <div key={s.id} className="flex items-center shrink-0">
                  <button
                    onClick={() => setActiveStage(s.id)}
                    className={`flex flex-col items-center gap-1.5 rounded-lg border px-3 py-2.5 transition-all min-w-[100px] ${
                      isActive ? 'border-accent-500/60 bg-accent-50 shadow-accent-glow' : isPast ? 'border-safe-500/30 bg-safe-500/5' : 'border-ivory-300 bg-ivory-50 hover:bg-ivory-100'
                    }`}
                  >
                    <Icon size={16} className={isActive ? 'text-accent-500' : isPast ? 'text-safe-500' : 'text-graphite-400'} />
                    <span className={`tech-label text-xs ${isActive ? 'text-accent-500' : 'text-graphite-400'}`}>{s.label}</span>
                  </button>
                  {i < pipelineStages.length - 1 && (
                    <svg width="20" height="2" className="shrink-0"><line x1="0" y1="1" x2="20" y2="1" stroke={isPast ? '#3FB984' : '#E4E1D8'} strokeWidth="1" strokeDasharray="2 2" /></svg>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </Panel>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Document preview with OCR regions */}
        <div className="lg:col-span-7">
          <Panel label="DOCUMENT PREVIEW" title="Boiler-3_Inspection_2026.pdf — Page 7" action={
            <div className="flex items-center gap-2">
              <Badge variant="accent">OCR ACTIVE</Badge>
              <Badge variant="default">24 PAGES</Badge>
            </div>
          }>
            <div className="p-4">
              <div className="relative rounded-lg border border-ivory-300 bg-ivory-50 overflow-hidden scan-overlay" style={{ aspectRatio: '3/4', maxHeight: '500px' }}>
                {/* Mock document with OCR regions */}
                <div className="absolute inset-0 p-[8%]">
                  <div className="text-center mb-4">
                    <div className="text-sm font-semibold text-graphite-600">Boiler-3 Annual Inspection Report</div>
                    <div className="tech-label text-xs text-graphite-400 mt-1">INSPECTION DATE: 2026-09-12</div>
                  </div>
                  <div className="space-y-2 text-xs text-graphite-400">
                    <p>Inspector: Inspector A, Senior Engineer</p>
                    <p>Location: Unit-3, Boiler House (sample)</p>
                  </div>
                </div>

                {/* OCR region overlays */}
                {ocrRegions.map((region) => (
                  <motion.button
                    key={region.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.1 }}
                    onClick={() => setSelectedRegion(region.id)}
                    className={`absolute border-2 rounded transition-all ${
                      selectedRegion === region.id
                        ? 'border-accent-500 bg-accent-500/10 shadow-accent-glow'
                        : 'border-accent-300/40 bg-accent-300/5 hover:border-accent-400'
                    }`}
                    style={{
                      left: `${region.x}%`,
                      top: `${region.y}%`,
                      width: `${region.w}%`,
                      height: `${region.h}%`,
                    }}
                  >
                    <span className="absolute -top-5 left-0 tech-label text-xs text-accent-500 bg-ivory-50 px-1 rounded whitespace-nowrap">
                      {region.label} ({(region.confidence * 100).toFixed(0)}%)
                    </span>
                  </motion.button>
                ))}

                {/* Scan line animation */}
                <div className="absolute inset-0 pointer-events-none overflow-hidden">
                  <motion.div
                    className="absolute left-0 right-0 h-px bg-accent-500/30"
                    animate={{ top: ['0%', '100%', '0%'] }}
                    transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                  />
                </div>
              </div>

              {/* Region details */}
              {selectedRegion && (
                <div className="mt-3 rounded-lg bg-ivory-100 p-3">
                  <div className="flex items-center justify-between mb-1">
                    <TechnicalLabel accent>SELECTED REGION</TechnicalLabel>
                    <Badge variant={ocrRegions.find(r => r.id === selectedRegion)?.confidence ?? 0 > 0.9 ? 'safe' : 'warning'}>
                      CONFIDENCE: {((ocrRegions.find(r => r.id === selectedRegion)?.confidence ?? 0) * 100).toFixed(0)}%
                    </Badge>
                  </div>
                  <div className="text-sm text-graphite-500">{ocrRegions.find(r => r.id === selectedRegion)?.label}</div>
                </div>
              )}
            </div>
          </Panel>
        </div>

        {/* Right — Extracted entities + doc types */}
        <div className="lg:col-span-5 space-y-4">
          <Panel label="EXTRACTED ENTITIES" title="Structured Data">
            <div className="p-4 space-y-2">
              {[
                { key: 'Equipment', value: 'Boiler-3', conf: 0.98 },
                { key: 'Inspection Date', value: '2026-09-12', conf: 0.96 },
                { key: 'Wall Thickness', value: '6.2mm', conf: 0.93 },
                { key: 'Min Required', value: '4.4mm (Sample Code cl. 4.2)', conf: 0.91 },
                { key: 'Inspector', value: 'Inspector A', conf: 0.95 },
                { key: 'Condition', value: 'ACCEPTABLE', conf: 0.95 },
                { key: 'Safety Margin', value: '1.8mm', conf: 0.90 },
              ].map((e) => (
                <div key={e.key} className="flex items-center justify-between py-1.5 hairline-b last:border-0">
                  <div>
                    <div className="tech-label text-xs text-graphite-400">{e.key.toUpperCase()}</div>
                    <div className="text-sm text-graphite-600 mt-0.5">{e.value}</div>
                  </div>
                  <Badge variant={e.conf > 0.9 ? 'safe' : 'warning'}>{(e.conf * 100).toFixed(0)}%</Badge>
                </div>
              ))}
            </div>
          </Panel>

          <Panel label="SUPPORTED FORMATS" title="Document Types">
            <div className="p-4 space-y-2">
              {docTypes.map((d) => (
                <div key={d.type} className="flex items-center justify-between py-1.5">
                  <div className="flex items-center gap-2">
                    <FileText size={14} className="text-graphite-400" />
                    <span className="text-sm text-graphite-500">{d.type}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="tech-label text-xs text-graphite-400">{d.count} files</span>
                    <CheckCircle2 size={12} className="text-safe-500" />
                  </div>
                </div>
              ))}
              <div className="rounded-lg border border-amber-400/40 bg-amber-400/5 p-3 mt-3">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle size={12} className="text-amber-500" />
                  <span className="tech-label text-xs text-amber-600">DRAWING INTELLIGENCE</span>
                </div>
                <div className="text-xs text-graphite-500">
                  For engineering drawings, the system extracts tags, labels, and structured metadata. It does not claim full semantic understanding of complex P&ID topology.
                </div>
              </div>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

export default MultimodalView;
