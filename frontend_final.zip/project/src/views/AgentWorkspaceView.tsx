import { useState, useEffect, useRef, lazy, Suspense, type ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FileText,
  Folder,
  FolderOpen,
  ChevronRight,
  CheckCircle2,
  Circle,
  Upload,
  Play,
  Pause,
  Paperclip,
  Send,
  Clock,
} from 'lucide-react';
import {
  Panel, TechnicalLabel, Badge, StatusIndicator, AgentStepCircle, ApprovalGate, Button,
} from '@/components/ui/primitives';
import {
  fileTree, agentStages, initialTrace, planSteps, type FileNode, type AgentStage,
} from '@/data/mockData';
import { useSession } from '@/lib/session';
import { DEMO_MODE } from '@/lib/runtime';

import { EffectsGate } from '@/components/three/EffectsGate';
const AgentActivityViz = lazy(() => import('@/components/three/AgentActivityViz'));

function FileTreeItem({ node, depth = 0 }: { node: FileNode; depth?: number }) {
  const [open, setOpen] = useState(depth < 1);
  if (node.type === 'folder') {
    return (
      <div>
        <button
          onClick={() => setOpen(!open)}
          className="flex items-center gap-1.5 w-full px-2 py-1.5 text-sm text-graphite-500 hover:bg-ivory-200/50 rounded transition-colors"
          style={{ paddingLeft: `${depth * 12 + 8}px` }}
        >
          <ChevronRight size={12} className={`text-graphite-400 transition-transform ${open ? 'rotate-90' : ''}`} />
          {open ? <FolderOpen size={14} className="text-accent-500" /> : <Folder size={14} className="text-graphite-400" />}
          <span className="truncate">{node.name}</span>
        </button>
        <AnimatePresence>
          {open && node.children && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              {node.children.map((child) => (
                <FileTreeItem key={child.id} node={child} depth={depth + 1} />
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }
  return (
    <div
      className="flex items-center gap-1.5 px-2 py-1.5 text-sm text-graphite-400 hover:bg-ivory-200/50 rounded cursor-pointer"
      style={{ paddingLeft: `${depth * 12 + 24}px` }}
    >
      <FileText size={12} className="text-graphite-400" />
      <span className="truncate flex-1">{node.name}</span>
      {node.fileType && <Badge variant="default" className="text-xs">{node.fileType}</Badge>}
    </div>
  );
}

const traceCategoryColors: Record<string, string> = {
  'MODEL ROUTER': 'text-accent-500',
  'TOOL CALL': 'text-graphite-500',
  'KB SEARCH': 'text-safe-500',
  'OCR': 'text-accent-500',
  'CALCULATION': 'text-amber-500',
  'SANDBOX': 'text-amber-500',
  'VERIFICATION': 'text-safe-500',
  'DELIVERABLE': 'text-accent-500',
  'NETWORK': 'text-danger-500',
};

const QUEUE_TICKS = 2; // ticks spent waiting for the GPU
const RUN_TICKS = 12; // ticks the simulated run takes
const DEFAULT_PROMPT = 'Analyze the inspection report and prepare an approval note.';
const stageOrder: AgentStage[] = ['PLAN', 'ACT', 'OBSERVE', 'VERIFY', 'REVISE', 'DELIVER'];

export function AgentWorkspaceView() {
  const { can } = useSession();
  const canApprove = can('approve');

  const [activeStage, setActiveStage] = useState<AgentStage>('DELIVER');
  const [approved, setApproved] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [running, setRunning] = useState(true);
  const [simulating, setSimulating] = useState(false);
  const [tick, setTick] = useState(0);
  const [taskText, setTaskText] = useState(DEFAULT_PROMPT);
  const [draft, setDraft] = useState(DEFAULT_PROMPT);
  const [attached, setAttached] = useState<string[]>([]);
  const [visibility, setVisibility] = useState<'Private' | 'Shared'>('Private');
  const fileInput = useRef<HTMLInputElement>(null);

  // Derived run state (simulation): queue -> stages -> deliver
  const inQueue = simulating && tick < QUEUE_TICKS;
  const runTick = simulating ? Math.max(0, tick - QUEUE_TICKS) : 0;
  const queuePos = inQueue ? QUEUE_TICKS - tick : 0;
  const shownStage: AgentStage = simulating
    ? stageOrder[Math.min(stageOrder.length - 1, Math.floor(runTick / 2))]
    : activeStage;
  const shownCount = simulating ? (inQueue ? 0 : Math.min(initialTrace.length, runTick + 1)) : initialTrace.length;
  const trace = initialTrace.slice(0, shownCount);
  const activeIdx = stageOrder.indexOf(shownStage);
  const showApproval = !simulating && shownStage === 'DELIVER' && !approved && !submitted;

  useEffect(() => {
    if (!simulating || !running) return;
    const id = window.setInterval(() => setTick((t) => t + 1), 800);
    return () => window.clearInterval(id);
  }, [simulating, running]);

  useEffect(() => {
    if (simulating && tick >= QUEUE_TICKS + RUN_TICKS) {
      setSimulating(false);
      setActiveStage('DELIVER');
      setRunning(true);
    }
  }, [simulating, tick]);

  const stageStatus = (stage: AgentStage): 'pending' | 'active' | 'complete' | 'blocked' | 'awaiting-approval' => {
    if (approved && stage === 'DELIVER') return 'complete';
    const idx = stageOrder.indexOf(stage);
    if (idx < activeIdx) return 'complete';
    if (idx === activeIdx) {
      if (inQueue) return 'pending';
      if (showApproval) return 'awaiting-approval';
      return 'active';
    }
    return 'pending';
  };

  const startRun = () => {
    const text = draft.trim();
    if (!text || simulating) return;
    setTaskText(text);
    setApproved(false);
    setSubmitted(false);
    setActiveStage('PLAN');
    setTick(0);
    setRunning(true);
    setSimulating(true);
  };

  const handleFiles = (e: ChangeEvent<HTMLInputElement>) => {
    // Demo only: keeps the file NAMES in memory; nothing is uploaded anywhere.
    const names = Array.from(e.target.files ?? []).map((f) => f.name);
    if (names.length) setAttached((prev) => [...prev, ...names]);
    e.target.value = '';
  };

  const handleApprove = () => { setApproved(true); setRunning(false); };
  const handleReject = () => { setActiveStage('REVISE'); };
  const handleRevision = () => { setActiveStage('REVISE'); };

  const runStage = (stage: AgentStage) => {
    if (simulating) return;
    setActiveStage(stage);
    setApproved(false);
    setSubmitted(false);
    setRunning(true);
  };

  const statusLabel = approved
    ? 'COMPLETE'
    : inQueue
      ? `QUEUE #${queuePos}`
      : submitted
        ? 'SUBMITTED'
        : showApproval
          ? 'AWAITING APPROVAL'
          : running
            ? 'EXECUTING'
            : 'PAUSED';

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">DEMO-IA-2026 / AGENT COMMAND SURFACE</TechnicalLabel>
          <h2 className="text-editorial-sm text-graphite-700">Agent Workspace</h2>
        </div>
        <div className="flex items-center gap-2">
          {running ? (
            <Button variant="secondary" size="sm" icon={<Pause size={14} />} onClick={() => setRunning(false)}>Pause</Button>
          ) : (
            <Button variant="primary" size="sm" icon={<Play size={14} />} onClick={() => setRunning(true)}>Resume</Button>
          )}
          <Badge variant="accent">INSPECTOR AGENT</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* LEFT — Files */}
        <div className="lg:col-span-3 space-y-4">
          <Panel label="PROJECT" title="DEMO-IA-2026">
            <div className="px-4 py-3 hairline-b">
              <div className="text-sm font-medium text-graphite-600">Inspection Analysis</div>
              <div className="text-xs text-graphite-400 mt-1">Boiler-3 annual inspection → approval note generation</div>
            </div>
            <div className="p-2">
              <TechnicalLabel className="px-2 py-1 block">FILE TREE</TechnicalLabel>
              {fileTree.map((node) => (
                <FileTreeItem key={node.id} node={node} />
              ))}
            </div>
          </Panel>

          <Panel label="UPLOAD" title="Add Document">
            <div className="p-4">
              <div onClick={() => fileInput.current?.click()} role="button" tabIndex={0} className="rounded-lg border-2 border-dashed border-ivory-300 p-6 text-center hover:border-accent-300 transition-colors cursor-pointer">
                <Upload size={20} className="mx-auto text-graphite-400 mb-2" />
                <div className="text-xs text-graphite-400">Drop files or click to upload</div>
                <div className="tech-label text-xs text-graphite-400 mt-1">PDF · DOCX · DWG · IMG</div>
              </div>
            </div>
          </Panel>
        </div>

        {/* CENTER — Agent execution */}
        <div className="lg:col-span-6 space-y-4">
          <Panel label="NEW TASK" title="Describe the work">
            <div className="p-4 space-y-3">
              <textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                rows={3}
                className="w-full resize-none rounded-md border border-ivory-300 bg-ivory-50 px-3 py-2 text-sm text-graphite-600 outline-none focus:border-accent-300"
                placeholder="e.g. Summarise the findings in this report and draft an approval note"
              />
              {attached.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {attached.map((n, i) => (
                    <span key={`${n}-${i}`} className="inline-flex items-center gap-1 rounded bg-ivory-200 px-2 py-0.5 text-xs text-graphite-500">
                      <Paperclip size={10} />{n}
                    </span>
                  ))}
                </div>
              )}
              <div className="flex flex-wrap items-center gap-2">
                <Button variant="secondary" size="sm" icon={<Paperclip size={14} />} onClick={() => fileInput.current?.click()}>Attach files</Button>
                <div className="flex items-center overflow-hidden rounded-md border border-ivory-300" role="group" aria-label="Task visibility">
                  {(['Private', 'Shared'] as const).map((v) => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => setVisibility(v)}
                      className={`px-2.5 py-1 text-xs ${visibility === v ? 'bg-accent-50 text-accent-600' : 'bg-ivory-50 text-graphite-400 hover:text-graphite-600'}`}
                    >
                      {v === 'Private' ? 'Private to me' : 'Share with project'}
                    </button>
                  ))}
                </div>
                <div className="ml-auto flex items-center gap-2">
                  <span className="tech-label text-xs text-graphite-400">MODEL: AUTO-ROUTED</span>
                  <Button variant="primary" size="sm" icon={<Send size={14} />} disabled={!draft.trim() || simulating} onClick={startRun}>Run task</Button>
                </div>
              </div>
              <input ref={fileInput} type="file" multiple className="hidden" onChange={handleFiles} />
            </div>
          </Panel>

          <Panel label="TASK" title="Active Task" action={<Badge variant={visibility === 'Shared' ? 'accent' : 'default'}>{visibility.toUpperCase()}</Badge>}>
            <div className="px-4 py-3 hairline-b space-y-2">
              <div className="text-sm text-graphite-600 font-medium">"{taskText}"</div>
              {inQueue && (
                <div className="flex items-center gap-2 text-xs text-amber-600">
                  <Clock size={12} />
                  Waiting for the GPU: position {queuePos} in the queue. One request is processed at a time.
                </div>
              )}
            </div>
          </Panel>

          {/* Agent Plan Visualization */}
          <Panel label="AGENT LOOP" title="Execution Pipeline" action={
            <StatusIndicator status={approved ? 'success' : inQueue ? 'pending' : running && !showApproval && !submitted ? 'running' : 'pending'} label={statusLabel} animate />
          }>
            <div className="p-4">
              {/* Stage flow diagram */}
              <div className="space-y-1">
                {agentStages.map((s, i) => {
                  const status = stageStatus(s.stage);
                  const isActive = s.stage === shownStage;
                  return (
                    <div key={s.stage}>
                      <div onClick={() => runStage(s.stage)} className="cursor-pointer">
                        <AgentStepCircle
                          label={s.label}
                          status={status}
                          index={i}
                          active={isActive}
                        />
                      </div>
                      {i < agentStages.length - 1 && (
                        <div className="flex justify-center py-0.5">
                          <svg width="2" height="16" className="text-graphite-200">
                            <line x1="1" y1="0" x2="1" y2="16" stroke="currentColor" strokeWidth="1" strokeDasharray="2 2" className={status === 'complete' ? 'text-safe-500' : 'text-graphite-200'} />
                          </svg>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Current stage detail */}
              <div className="mt-4 rounded-lg bg-ivory-100 p-3 hairline-t">
                <TechnicalLabel accent className="mb-2 block">CURRENT STAGE — {shownStage}</TechnicalLabel>
                <div className="text-sm text-graphite-500">
                  {agentStages.find(s => s.stage === shownStage)?.description}
                </div>

                {/* Plan steps (visible during PLAN stage or after) */}
                {(shownStage === 'PLAN' || activeIdx > 0) && (
                  <div className="mt-3 space-y-1.5">
                    {planSteps.map((ps, i) => {
                      const stepComplete = activeIdx > 0 || i < planSteps.length - 1;
                      return (
                        <div key={ps.id} className="flex items-start gap-2 text-xs">
                          {stepComplete ? <CheckCircle2 size={12} className="text-safe-500 mt-0.5" /> : <Circle size={12} className="text-graphite-200 mt-0.5" />}
                          <span className="text-graphite-500 flex-1">{ps.label}</span>
                          <span className="tech-label text-xs text-graphite-400">{ps.model}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Approval gate */}
              <div className="mt-4">
                <ApprovalGate
                  visible={showApproval && canApprove}
                  onApprove={handleApprove}
                  onReject={handleReject}
                  onRevision={handleRevision}
                />
                {showApproval && !canApprove && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="rounded-xl border border-amber-400/40 bg-amber-400/5 p-4"
                  >
                    <div className="mb-2 flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full bg-amber-500 animate-pulse-soft" />
                      <span className="tech-label text-amber-600">DRAFT READY</span>
                    </div>
                    <div className="mb-3 text-sm text-graphite-500">
                      Only a Manager can approve deliverables. Submit this draft to your manager for review.
                    </div>
                    <Button variant="primary" size="sm" onClick={() => setSubmitted(true)}>Submit for manager approval</Button>
                  </motion.div>
                )}
                {submitted && !approved && (
                  <div className="rounded-xl border border-accent-500/30 bg-accent-50 p-4">
                    <span className="tech-label text-accent-600">SUBMITTED</span>
                    <div className="mt-1 text-sm text-graphite-500">
                      Sent to manager@demo.local for review. The submission is written to the audit log.
                    </div>
                  </div>
                )}
                {approved && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="rounded-xl border border-safe-500/30 bg-safe-500/5 p-4"
                  >
                    <div className="flex items-center gap-2">
                      <CheckCircle2 size={16} className="text-safe-500" />
                      <span className="tech-label text-safe-600">DELIVERABLE APPROVED</span>
                    </div>
                    <div className="text-sm text-graphite-500 mt-2">
                      Approval note generated and saved to deliverables. Audit event recorded with hash-chain verification.
                    </div>
                  </motion.div>
                )}
              </div>
            </div>
          </Panel>
        </div>

        {/* RIGHT — Live Trace */}
        <div className="lg:col-span-3">
          <Panel label="LIVE TRACE" title="Execution Log" className="relative overflow-hidden" action={
            <StatusIndicator status={simulating ? 'running' : 'success'} label={simulating ? 'RUNNING' : DEMO_MODE ? 'SAMPLE RUN' : 'LIVE'} animate={simulating} />
          }>
            <div className="absolute inset-0 opacity-20 pointer-events-none">
              <EffectsGate>
                <Suspense fallback={null}>
                  <AgentActivityViz />
                </Suspense>
              </EffectsGate>
            </div>
            <div className="relative max-h-[600px] overflow-y-auto dark-scroll">
              <div className="divide-y divide-ivory-200">
                {trace.length === 0 && (
                  <div className="px-3 py-4 text-xs text-graphite-400">{inQueue ? 'Waiting in the queue…' : 'No events yet.'}</div>
                )}
                {trace.map((t) => (
                  <div key={t.id} className="px-3 py-2.5">
                    <div className="flex items-center justify-between mb-1">
                      <span className={`tech-label text-xs ${traceCategoryColors[t.category] || 'text-graphite-400'}`}>
                        {t.category}
                      </span>
                      <span className="tech-label text-xs text-graphite-400">{t.time}</span>
                    </div>
                    <div className="text-xs text-graphite-500 font-medium">{t.action}</div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-graphite-400">{t.result}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="tech-label text-xs text-graphite-400">{t.duration}</span>
                      <span className="tech-label text-xs text-graphite-400">·</span>
                      <span className="tech-label text-xs text-graphite-400">{t.source}</span>
                      {t.status === 'success' && <CheckCircle2 size={10} className="text-safe-500 ml-auto" />}
                      {t.status === 'running' && <StatusIndicator status="running" label="" animate />}
                      {t.status === 'blocked' && <StatusIndicator status="blocked" label="" />}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

export default AgentWorkspaceView;
