import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  FolderKanban, FileText, Cpu, Activity, Boxes,
  FileCheck, ShieldCheck, ArrowRight, Users, Lock,
} from 'lucide-react';
import { Panel, TechnicalLabel, Badge, Button } from '@/components/ui/primitives';
import { projects, projectMembers, projectActivity, type ProjectInfo } from '@/data/mockData';
import { useSession } from '@/lib/session';

export function ProjectsView({ onNavigate }: { onNavigate: (v: string) => void }) {
  const { role, username, clearance } = useSession();
  const canInvite = role !== 'Engineer';
  const [selected, setSelected] = useState<ProjectInfo>(projects[0]);
  const [filter, setFilter] = useState<'active' | 'archived' | 'all'>('active');

  const filtered = filter === 'all' ? projects : projects.filter(p => p.status === filter);

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">PROJECT WORKSPACES / ENGINEERING PROJECTS</TechnicalLabel>
          <h2 className="text-editorial-sm text-graphite-700">Projects</h2>
        </div>
        <div className="flex items-center gap-2">
          {(['active', 'archived', 'all'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-md border px-2.5 py-1 tech-label text-xs transition-colors capitalize ${
                filter === f ? 'border-accent-500/60 bg-accent-50 text-accent-600' : 'border-ivory-300 bg-ivory-50 text-graphite-400 hover:text-graphite-500'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Project list */}
        <div className="lg:col-span-1 space-y-2">
          {filtered.map((p) => (
            <button
              key={p.id}
              onClick={() => setSelected(p)}
              className={`w-full text-left rounded-xl border p-4 transition-all ${
                selected.id === p.id ? 'border-accent-500/60 bg-accent-50 shadow-panel' : 'panel-ivory hover:shadow-panel'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <FolderKanban size={16} className={selected.id === p.id ? 'text-accent-500' : 'text-graphite-400'} />
                  <span className="tech-label text-xs text-graphite-400">{p.code}</span>
                </div>
                <Badge variant={p.status === 'active' ? 'safe' : 'default'}>{p.status.toUpperCase()}</Badge>
              </div>
              <div className="text-sm font-medium text-graphite-700 mb-1">{p.name}</div>
              <div className="text-xs text-graphite-400 line-clamp-2">{p.description}</div>
            </button>
          ))}
        </div>

        {/* Project detail */}
        <div className="lg:col-span-2">
          <motion.div
            key={selected.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
          >
            <Panel label={selected.code} title={selected.name} action={
              <Badge variant={selected.status === 'active' ? 'safe' : 'default'}>{selected.status.toUpperCase()}</Badge>
            }>
              <div className="p-6 space-y-4">
                <p className="text-sm text-graphite-500 leading-relaxed">{selected.description}</p>

                {/* Stats grid */}
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                  {[
                    { icon: FileText, label: 'DOCUMENTS', value: selected.documents },
                    { icon: Cpu, label: 'AGENTS', value: selected.agents },
                    { icon: Activity, label: 'TASKS', value: selected.tasks },
                    { icon: Boxes, label: 'MODELS', value: selected.models },
                    { icon: FileCheck, label: 'DELIVERABLES', value: selected.deliverables },
                    { icon: ShieldCheck, label: 'AUDIT EVENTS', value: selected.auditEvents },
                  ].map((s) => {
                    const Icon = s.icon;
                    return (
                      <div key={s.label} className="rounded-lg border border-ivory-300 bg-ivory-50 p-3">
                        <Icon size={14} className="text-graphite-400 mb-2" />
                        <div className="text-lg font-semibold text-graphite-700">{s.value}</div>
                        <div className="tech-label text-xs text-graphite-400 mt-0.5">{s.label}</div>
                      </div>
                    );
                  })}
                </div>

                {/* Quick navigate */}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 pt-2">
                  {[
                    { label: 'Agent Workspace', view: 'agent', icon: Cpu },
                    { label: 'Knowledge Base', view: 'knowledge', icon: FileText },
                    { label: 'Models', view: 'models', icon: Boxes },
                    { label: 'Deliverables', view: 'deliverables', icon: FileCheck },
                    { label: 'Audit Trail', view: 'audit', icon: ShieldCheck },
                    { label: 'Sovereignty', view: 'sovereignty', icon: Activity },
                  ].map((nav) => {
                    const Icon = nav.icon;
                    return (
                      <button
                        key={nav.label}
                        onClick={() => onNavigate(nav.view)}
                        className="group flex items-center justify-between rounded-lg border border-ivory-300 bg-ivory-50 px-3 py-2.5 hover:border-accent-200/50 hover:shadow-panel transition-all"
                      >
                        <div className="flex items-center gap-2">
                          <Icon size={14} className="text-accent-500" />
                          <span className="text-xs font-medium text-graphite-600">{nav.label}</span>
                        </div>
                        <ArrowRight size={12} className="text-graphite-200 group-hover:text-accent-500 transition-colors" />
                      </button>
                    );
                  })}
                </div>
              </div>
            </Panel>

            {(() => {
              const members = projectMembers[selected.id] ?? [];
              const feed = projectActivity[selected.id] ?? [];
              const visibleFeed = feed.filter((a) => a.visibility === 'Shared' || a.user === username);
              const hiddenFeed = feed.length - visibleFeed.length;
              return (
                <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-2">
                  <Panel
                    label="MEMBERS"
                    title={`${members.length} ${members.length === 1 ? 'person' : 'people'}`}
                    action={
                      <Button
                        variant="secondary"
                        size="sm"
                        icon={<Users size={14} />}
                        disabled={!canInvite}
                        title={canInvite ? 'Invite a colleague to this project' : 'Managers and Admins can invite members'}
                      >
                        Invite
                      </Button>
                    }
                  >
                    <div className="divide-y divide-ivory-200">
                      <div className="px-4 py-2.5 text-xs text-graphite-400">
                        Signed in as {role} ({username}) · clearance {clearance}
                      </div>
                      {members.map((m) => (
                        <div key={m.email} className="flex items-center gap-3 px-4 py-2.5">
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-ivory-200 text-xs font-semibold text-graphite-500">
                            {m.name.split(' ').map((w) => w[0]).join('').slice(0, 2)}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-sm font-medium text-graphite-600">{m.name}</div>
                            <div className="truncate text-xs text-graphite-400">{m.email}</div>
                          </div>
                          {m.email === username && <Badge variant="accent">YOU</Badge>}
                          <Badge variant={m.role === 'Manager' ? 'safe' : m.role === 'Admin' ? 'warning' : 'default'}>{m.role.toUpperCase()}</Badge>
                        </div>
                      ))}
                    </div>
                  </Panel>

                  <Panel label="ACTIVITY" title="Project feed">
                    <div className="divide-y divide-ivory-200">
                      {visibleFeed.map((a) => (
                        <div key={a.id} className="px-4 py-2.5">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs text-graphite-400">{a.time}</span>
                            <span className="truncate text-xs text-graphite-400">{a.user}</span>
                            <Badge variant={a.visibility === 'Shared' ? 'accent' : 'default'} className="ml-auto">{a.visibility.toUpperCase()}</Badge>
                          </div>
                          <div className="mt-0.5 text-sm text-graphite-600">{a.action}</div>
                        </div>
                      ))}
                      {hiddenFeed > 0 && (
                        <div className="flex gap-2 px-4 py-2.5 text-xs text-graphite-500">
                          <Lock size={12} className="mt-0.5 shrink-0 text-amber-500" />
                          <span>{hiddenFeed} private item{hiddenFeed > 1 ? 's' : ''} hidden. Work stays private to its owner until it is shared with the project.</span>
                        </div>
                      )}
                    </div>
                  </Panel>
                </div>
              );
            })()}
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export default ProjectsView;
