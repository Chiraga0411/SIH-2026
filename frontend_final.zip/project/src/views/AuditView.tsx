import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ShieldCheck,
  Hash,
  Link,
  CheckCircle2,
  AlertTriangle,
  X,
  XCircle,
} from 'lucide-react';
import { Panel, TechnicalLabel, Badge, StatusIndicator, Button } from '@/components/ui/primitives';
import { auditEntries, type AuditEntry } from '@/data/mockData';
import { verifyChain, type VerifyResult } from '@/lib/hashChain';

// Entry that the "Simulate tampering" button edits (a past OCR record).
const TAMPER_TARGET = 'a3';

export function AuditView() {
  const [filter, setFilter] = useState<string>('ALL');
  const [selectedEntry, setSelectedEntry] = useState<AuditEntry | null>(null);

  const actions = ['ALL', 'DELIVERABLE_GENERATED', 'EGRESS_BLOCKED', 'OCR_PROCESSED', 'MODEL_ROUTED', 'TASK_INITIATED', 'DELIVERABLE_APPROVED', 'SANDBOX_EXECUTED', 'INJECTION_FLAGGED', 'ACCESS_DENIED'];

  const [tamperedId, setTamperedId] = useState<string | null>(null);
  const [result, setResult] = useState<VerifyResult>(() => verifyChain(auditEntries));
  const [verifying, setVerifying] = useState(false);
  const [stale, setStale] = useState(false);

  // The log as currently stored. Tampering edits one record but leaves its old hash in place.
  const entries: AuditEntry[] = useMemo(
    () => auditEntries.map((e) => (e.id === tamperedId ? { ...e, resource: `${e.resource} [EDITED]` } : e)),
    [tamperedId],
  );

  const runVerify = () => {
    setVerifying(true);
    window.setTimeout(() => {
      setResult(verifyChain(entries));
      setStale(false);
      setVerifying(false);
    }, 700);
  };

  const toggleTamper = () => {
    setTamperedId((t) => (t ? null : TAMPER_TARGET));
    setStale(true);
  };

  const brokenId = !stale && !result.ok && result.brokenAt !== null ? entries[result.brokenAt].id : null;
  const rowState = (id: string): 'ok' | 'broken' | 'stale' => (id === brokenId ? 'broken' : stale ? 'stale' : 'ok');

  const filtered = filter === 'ALL' ? entries : entries.filter(e => e.action === filter);

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">AUDIT LOG / HASH-CHAINED INTEGRITY</TechnicalLabel>
          <h2 className="text-editorial-sm text-graphite-700">Audit Trail</h2>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {stale ? (
            <>
              <Badge variant="warning">CHANGED — RE-VERIFY</Badge>
              <StatusIndicator status="pending" label="NOT VERIFIED" />
            </>
          ) : result.ok ? (
            <>
              <Badge variant="safe">AUDIT CHAIN VERIFIED</Badge>
              <StatusIndicator status="success" label="INTEGRITY OK" />
            </>
          ) : (
            <>
              <Badge variant="danger">CHAIN BROKEN</Badge>
              <StatusIndicator status="error" label="TAMPER DETECTED" />
            </>
          )}
          <Button variant="primary" size="sm" icon={<ShieldCheck size={14} />} onClick={runVerify} disabled={verifying}>
            {verifying ? 'Verifying…' : 'Verify integrity'}
          </Button>
          <Button variant="secondary" size="sm" icon={<AlertTriangle size={14} />} onClick={toggleTamper} disabled={verifying}>
            {tamperedId ? 'Restore original' : 'Simulate tampering'}
          </Button>
        </div>
      </div>

      {/* Hash chain visualization */}
      <Panel label="HASH CHAIN" title="Integrity Verification">
        <div className="p-4">
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {entries.slice(0, 6).reverse().map((entry, i) => (
              <div key={entry.id} className="flex items-center shrink-0">
                <div className="flex flex-col items-center gap-1">
                  <div className={`rounded-lg border px-3 py-2 ${entry.id === brokenId ? 'border-danger-500/60 bg-danger-500/5' : i === 0 ? 'border-accent-500/40 bg-accent-50' : 'border-ivory-300 bg-ivory-50'}`}>
                    <Hash size={12} className={i === 0 ? 'text-accent-500' : 'text-graphite-400'} />
                    <div className="tech-label text-xs text-graphite-400 mt-1 font-mono">{entry.hash.slice(0, 8)}</div>
                  </div>
                  {rowState(entry.id) === 'broken' ? <XCircle size={10} className="text-danger-500" /> : rowState(entry.id) === 'stale' ? <AlertTriangle size={10} className="text-amber-500" /> : <CheckCircle2 size={10} className="text-safe-500" />}
                </div>
                {i < 5 && (
                  <svg width="30" height="2" className="shrink-0">
                    <line x1="0" y1="1" x2="30" y2="1" stroke="#3FB984" strokeWidth="1" className="dash-flow" />
                  </svg>
                )}
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center gap-2">
            <Link size={12} className="text-safe-500" />
            <span className="text-xs text-graphite-400">
              {stale
                ? 'A record changed since the last check. Run "Verify integrity" to re-hash every entry.'
                : result.ok
                  ? `Verified: ${result.checked} entries re-hashed with SHA-256. Each hash matches its content and links to the previous entry.`
                  : `Tamper detected at entry ${result.brokenAt !== null ? entries[result.brokenAt].id : '?'}: ${result.reason}. Treat this record, and the chain built on it, as untrusted.`}
            </span>
          </div>
        </div>
      </Panel>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        {actions.map((a) => (
          <button
            key={a}
            onClick={() => setFilter(a)}
            className={`rounded-md border px-2.5 py-1 tech-label text-xs transition-colors ${
              filter === a ? 'border-accent-500/60 bg-accent-50 text-accent-600' : 'border-ivory-300 bg-ivory-50 text-graphite-400 hover:text-graphite-500'
            }`}
          >
            {a.replace(/_/g, ' ')}
          </button>
        ))}
      </div>

      {/* Audit table */}
      <Panel label="EVENT LOG" title={`${filtered.length} Events`}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="hairline-b">
                <th className="text-left px-4 py-2.5 tech-label text-xs text-graphite-400 font-medium">TIME</th>
                <th className="text-left px-4 py-2.5 tech-label text-xs text-graphite-400 font-medium">USER</th>
                <th className="text-left px-4 py-2.5 tech-label text-xs text-graphite-400 font-medium">ACTION</th>
                <th className="text-left px-4 py-2.5 tech-label text-xs text-graphite-400 font-medium">RESOURCE</th>
                <th className="text-left px-4 py-2.5 tech-label text-xs text-graphite-400 font-medium">MODEL</th>
                <th className="text-left px-4 py-2.5 tech-label text-xs text-graphite-400 font-medium">RESULT</th>
                <th className="text-left px-4 py-2.5 tech-label text-xs text-graphite-400 font-medium">HASH</th>
                <th className="text-left px-4 py-2.5 tech-label text-xs text-graphite-400 font-medium">STATUS</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((entry) => (
                <tr
                  key={entry.id}
                  onClick={() => setSelectedEntry(entry)}
                  className="hairline-b hover:bg-ivory-100/50 cursor-pointer transition-colors"
                >
                  <td className="px-4 py-2.5 text-xs font-mono text-graphite-400 whitespace-nowrap">{entry.time}</td>
                  <td className="px-4 py-2.5 text-xs text-graphite-500">{entry.user}</td>
                  <td className="px-4 py-2.5"><span className="tech-label text-xs text-graphite-500">{entry.action.replace(/_/g, ' ')}</span></td>
                  <td className="px-4 py-2.5 text-xs text-graphite-500 max-w-[200px] truncate">{entry.resource}</td>
                  <td className="px-4 py-2.5 text-xs text-graphite-400">{entry.model}</td>
                  <td className="px-4 py-2.5">
                    <Badge variant={entry.result === 'DENIED' ? 'danger' : entry.result === 'SUCCESS' || entry.result === 'APPROVED' || entry.result === 'LOADED' ? 'safe' : 'warning'}>
                      {entry.result}
                    </Badge>
                  </td>
                  <td className="px-4 py-2.5 text-xs font-mono text-graphite-400">{entry.hash.slice(0, 10)}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1">
                      {rowState(entry.id) === 'broken' ? (
                        <><XCircle size={12} className="text-danger-500" /><span className="tech-label text-xs text-danger-500">TAMPERED</span></>
                      ) : rowState(entry.id) === 'stale' ? (
                        <><AlertTriangle size={12} className="text-amber-500" /><span className="tech-label text-xs text-amber-600">UNVERIFIED</span></>
                      ) : (
                        <><CheckCircle2 size={12} className="text-safe-500" /><span className="tech-label text-xs text-safe-500">VERIFIED</span></>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      {/* Detail modal */}
      <AnimatePresence>
        {selectedEntry && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-graphite-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedEntry(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              onClick={(e) => e.stopPropagation()}
              className="panel-ivory rounded-xl p-6 max-w-lg w-full shadow-panel-lg"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <ShieldCheck size={18} className="text-safe-500" />
                  <span className="text-base font-semibold text-graphite-700">Audit Event Detail</span>
                </div>
                <button onClick={() => setSelectedEntry(null)} className="text-graphite-400 hover:text-graphite-500"><X size={18} /></button>
              </div>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div><div className="tech-label text-xs text-graphite-400">TIME</div><div className="text-sm text-graphite-600 font-mono mt-0.5">{selectedEntry.time}</div></div>
                  <div><div className="tech-label text-xs text-graphite-400">USER</div><div className="text-sm text-graphite-600 mt-0.5">{selectedEntry.user}</div></div>
                  <div><div className="tech-label text-xs text-graphite-400">ACTION</div><div className="text-sm text-graphite-600 mt-0.5">{selectedEntry.action.replace(/_/g, ' ')}</div></div>
                  <div><div className="tech-label text-xs text-graphite-400">RESULT</div><div className="text-sm text-graphite-600 mt-0.5"><Badge variant={selectedEntry.result === 'DENIED' ? 'danger' : 'safe'}>{selectedEntry.result}</Badge></div></div>
                </div>
                <div><div className="tech-label text-xs text-graphite-400">RESOURCE</div><div className="text-sm text-graphite-600 mt-0.5">{selectedEntry.resource}</div></div>
                <div className="rounded-lg bg-ivory-100 p-3 space-y-2">
                  <div><div className="tech-label text-xs text-graphite-400">CURRENT HASH</div><div className="text-xs font-mono text-graphite-600 mt-0.5">{selectedEntry.hash}</div></div>
                  <div><div className="tech-label text-xs text-graphite-400">PREVIOUS HASH</div><div className="text-xs font-mono text-graphite-600 mt-0.5">{selectedEntry.prevHash}</div></div>
                </div>
                {rowState(selectedEntry.id) === 'broken' ? (
                  <div className="flex items-center gap-2 rounded-lg border border-danger-500/30 bg-danger-500/5 p-3">
                    <XCircle size={16} className="text-danger-500" />
                    <span className="text-sm font-medium text-danger-600">Integrity: TAMPERED</span>
                    <span className="ml-auto text-xs text-graphite-400">Content does not match stored hash</span>
                  </div>
                ) : rowState(selectedEntry.id) === 'stale' ? (
                  <div className="flex items-center gap-2 rounded-lg border border-amber-400/30 bg-amber-400/5 p-3">
                    <AlertTriangle size={16} className="text-amber-500" />
                    <span className="text-sm font-medium text-amber-600">Integrity: NOT VERIFIED</span>
                    <span className="ml-auto text-xs text-graphite-400">Run Verify integrity</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 rounded-lg border border-safe-500/30 bg-safe-500/5 p-3">
                    <CheckCircle2 size={16} className="text-safe-500" />
                    <span className="text-sm text-safe-600 font-medium">Integrity: VERIFIED</span>
                    <span className="text-xs text-graphite-400 ml-auto">Hash chain intact</span>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default AuditView;
