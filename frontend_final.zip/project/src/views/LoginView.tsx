import { useState, lazy, Suspense } from 'react';
import { motion } from 'framer-motion';
import { Lock, User, ChevronRight, ShieldCheck, Wifi } from 'lucide-react';
import { Button } from '@/components/ui/primitives';
import { ROLES, defaultUsername, type Role } from '@/lib/access';
import { useOnlineStatus } from '@/lib/useOnline';
import { DEMO_MODE } from '@/lib/runtime';

import { EffectsGate } from '@/components/three/EffectsGate';
const MeshFlow = lazy(() => import('@/components/three/MeshFlow'));

export function LoginView({ onLogin }: { onLogin: (role: Role, username: string) => void }) {
  const [username, setUsername] = useState(defaultUsername('Engineer'));
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<Role>('Engineer');
  const online = useOnlineStatus();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(role, username);
  };

  return (
    <div className="relative min-h-screen bg-graphite-900 overflow-hidden flex items-center justify-center px-4">
      {/* Background mesh */}
      <div className="absolute inset-0 opacity-40">
        <EffectsGate fallback={<div className="absolute inset-0 blueprint-grid-dark" />}>
          <Suspense fallback={<div className="absolute inset-0 blueprint-grid-dark" />}>
            <MeshFlow dark />
          </Suspense>
        </EffectsGate>
      </div>

      {/* Blueprint overlay */}
      <div className="absolute inset-0 blueprint-grid-dark opacity-30" />

      {/* Annotations */}
      <div className="absolute top-8 left-8 mesh-annotation text-graphite-300 hidden md:block">
        LOCAL INFERENCE / MODEL ROUTER / SANDBOX
      </div>
      <div className="absolute bottom-8 right-8 mesh-annotation text-graphite-300 hidden md:block">
        {DEMO_MODE ? 'DEMO BUILD / SYNTHETIC SAMPLE DATA' : 'AUDIT: ACTIVE'}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-md"
      >
        <div className="panel-dark rounded-xl p-8 shadow-panel-lg backdrop-blur-sm">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-8">
            <svg viewBox="0 0 32 32" className="h-10 w-10">
              <rect x="4" y="4" width="24" height="24" fill="none" stroke="#2E82F0" strokeWidth="1" />
              <rect x="8" y="8" width="16" height="16" fill="none" stroke="#2E82F0" strokeWidth="0.5" opacity="0.5" />
              <circle cx="16" cy="16" r="3" fill="none" stroke="#2E82F0" strokeWidth="1" />
              <line x1="16" y1="4" x2="16" y2="13" stroke="#2E82F0" strokeWidth="0.5" />
              <line x1="16" y1="19" x2="16" y2="28" stroke="#2E82F0" strokeWidth="0.5" />
              <line x1="4" y1="16" x2="13" y2="16" stroke="#2E82F0" strokeWidth="0.5" />
              <line x1="19" y1="16" x2="28" y2="16" stroke="#2E82F0" strokeWidth="0.5" />
            </svg>
            <div>
              <div className="text-lg font-semibold tracking-tight text-ivory-100">SOVEREIGN AI</div>
              <div className="tech-label text-xs text-graphite-200 mt-0.5">ON-PREMISE AGENTIC WORKBENCH</div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="tech-label text-xs text-graphite-200 block mb-1.5">USERNAME</label>
              <div className="relative">
                <User size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-graphite-300" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full rounded-md border border-graphite-400/30 bg-graphite-700/50 px-9 py-2.5 text-sm text-ivory-100 placeholder-graphite-300 outline-none transition-colors focus:border-accent-500/60"
                  placeholder="username"
                />
              </div>
            </div>

            <div>
              <label className="tech-label text-xs text-graphite-200 block mb-1.5">PASSWORD</label>
              <div className="relative">
                <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-graphite-300" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-md border border-graphite-400/30 bg-graphite-700/50 px-9 py-2.5 text-sm text-ivory-100 placeholder-graphite-300 outline-none transition-colors focus:border-accent-500/60"
                  placeholder="password"
                />
              </div>
            </div>

            <div>
              <label className="tech-label text-xs text-graphite-200 block mb-1.5">ROLE</label>
              <div className="grid grid-cols-3 gap-2">
                {ROLES.map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => { setRole(r); setUsername(defaultUsername(r)); }}
                    className={`rounded-md border px-3 py-2 text-sm transition-colors ${
                      role === r
                        ? 'border-accent-500/60 bg-accent-500/10 text-accent-300'
                        : 'border-graphite-400/30 bg-graphite-700/30 text-graphite-200 hover:text-ivory-100'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <Button type="submit" size="lg" className="w-full" icon={<ChevronRight size={18} />}>
              Open Workbench
            </Button>
          </form>

          {/* System status (real values only) */}
          <div className="mt-6 pt-6 hairline-t-dark space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-graphite-200">
                <Wifi size={12} className={online ? 'text-amber-400' : 'text-safe-400'} />
                <span className="tech-label text-xs">NETWORK LINK</span>
              </div>
              <span className={`tech-label text-xs ${online ? 'text-amber-400' : 'text-safe-400'}`}>{online ? 'ONLINE' : 'OFFLINE'}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-graphite-200">
                <ShieldCheck size={12} className={DEMO_MODE ? 'text-amber-400' : 'text-safe-400'} />
                <span className="tech-label text-xs">DATA MODE</span>
              </div>
              <span className={`tech-label text-xs ${DEMO_MODE ? 'text-amber-400' : 'text-safe-400'}`}>{DEMO_MODE ? 'DEMO (SAMPLE DATA)' : 'LIVE'}</span>
            </div>
            {DEMO_MODE && (
              <p className="pt-1 text-xs text-graphite-300">
                Demo build: no authentication backend is connected, so any credentials open the workbench.
              </p>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default LoginView;
