import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FileText, CheckCircle2, AlertTriangle, XCircle, Eye,
  Shield, BookOpen, Cpu, Beaker, Sparkles,
} from 'lucide-react';
import { Panel, TechnicalLabel, Badge, StatusIndicator, Button } from '@/components/ui/primitives';
import { auditEntries } from '@/data/mockData';
import { verifyChain } from '@/lib/hashChain';
import { useSession } from '@/lib/session';
import { DEMO_MODE } from '@/lib/runtime';

export function ApprovalView() {
  const [decision, setDecision] = useState<'none' | 'approved' | 'rejected' | 'revision'>('none');
  const { can, role } = useSession();
  const canDecide = can('approve');
  const auditOk = verifyChain(auditEntries).ok;

  const checks = [
    { label: 'Source Grounding', status: 'passed', detail: '3 documents · 7 passages verified' },
    { label: 'Calculation Verification', status: 'passed', detail: 'Wall thickness margin: 1.8mm · Safety ratio: 1.41' },
    { label: 'Compliance Check', status: 'passed', detail: 'Sample Code cl. 4.2 requirements met' },
    { label: 'Sandbox Integrity', status: 'passed', detail: 'Code executed in isolated environment · egress blocked' },
    { label: 'No External Dependencies', status: 'passed', detail: DEMO_MODE ? '0 external connections (sample data)' : '0 external connections during generation' },
    { label: 'Audit Trail', status: auditOk ? 'passed' : 'failed', detail: auditOk ? 'Hash chain re-computed and intact · event recorded' : 'Hash chain broken · do not approve' },
  ];

  const sources = [
    { doc: 'Boiler-3 Inspection Report 2026', page: 7, section: '§3 — Measurements' },
    { doc: 'Sample Boiler Code', page: 42, section: 'cl. 4.2 — Wall Thickness' },
    { doc: 'Past Approval Notes 2024', page: 12, section: 'Approval Summary' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">APPROVAL CENTER / HUMAN-IN-THE-LOOP</TechnicalLabel>
          <h2 className="text-editorial-sm text-graphite-700">Approval Center</h2>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="warning">PENDING REVIEW</Badge>
          <StatusIndicator status="warning" label="AWAITING APPROVAL" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Document preview */}
        <div className="lg:col-span-2">
          <Panel label="AI GENERATED DELIVERABLE" title="Approval_Note_Boiler3.docx" action={
            <Badge variant="accent">DRAFT v1.0</Badge>
          }>
            <div className="p-6">
              <div className="rounded-lg border border-ivory-300 bg-ivory-50 p-6 max-h-[500px] overflow-y-auto">
                {/* Mock Word doc */}
                <div className="text-center mb-6">
                  <div className="text-lg font-semibold text-graphite-700">APPROVAL NOTE</div>
                  <div className="text-sm text-graphite-400 mt-1">Boiler-3 Annual Inspection — September 2026</div>
                  <div className="tech-label text-xs text-graphite-400 mt-2">DEMO-IA-2026 · INSPECTOR AGENT</div>
                </div>

                <div className="space-y-4 text-sm text-graphite-500 leading-relaxed">
                  <div>
                    <div className="text-xs font-semibold text-graphite-600 mb-1">1. EXECUTIVE SUMMARY</div>
                    <p>The annual inspection of Boiler-3 has been completed on 2026-09-12. The boiler is assessed as <strong className="text-safe-600">ACCEPTABLE</strong> for continued operation, with all critical measurements meeting sample boiler code requirements.</p>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-graphite-600 mb-1">2. KEY FINDINGS</div>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Wall thickness at inspection point B-3: 6.2mm (minimum required: 4.4mm)</li>
                      <li>Safety margin: 1.8mm · Safety ratio: 1.41</li>
                      <li>No corrosion detected at critical junctions</li>
                      <li>All safety valves tested and operational</li>
                    </ul>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-graphite-600 mb-1">3. COMPLIANCE</div>
                    <p>Meets Sample Code cl. 4.2 wall thickness requirements. All inspections performed per SOP Rev 3. Historical degradation rate: 0.3mm/year (based on 2024 data).</p>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-graphite-600 mb-1">4. RECOMMENDATION</div>
                    <p>Continue operation. Next inspection scheduled for September 2027. Monitor wall thickness at B-3 inspection point during routine checks.</p>
                  </div>
                  <div className="hairline-t pt-3">
                    <div className="flex items-center justify-between text-xs text-graphite-400">
                      <span>Generated by: Inspector Agent (General-8B)</span>
                      <span>2026-09-20 09:14:27</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Panel>
        </div>

        {/* Right — reasoning, sources, checks */}
        <div className="space-y-4">
          <Panel label="AI REASONING" title="How This Was Generated">
            <div className="p-4 space-y-2 text-xs text-graphite-500">
              <div className="flex items-start gap-2">
                <Cpu size={12} className="text-accent-500 mt-0.5" />
                <span>Model router selected General-8B for document reasoning (32K context, high accuracy on regulatory text).</span>
              </div>
              <div className="flex items-start gap-2">
                <Eye size={12} className="text-accent-500 mt-0.5" />
                <span>Vision model processed the 24-page inspection PDF, extracting 187 OCR regions including handwritten inspector notes.</span>
              </div>
              <div className="flex items-start gap-2">
                <BookOpen size={12} className="text-safe-500 mt-0.5" />
                <span>Knowledge base retrieved 7 relevant passages from 3 documents with 0.91 average confidence.</span>
              </div>
              <div className="flex items-start gap-2">
                <Beaker size={12} className="text-amber-500 mt-0.5" />
                <span>Sandbox verified wall thickness calculation: margin 1.8mm confirmed via isolated Python execution.</span>
              </div>
              <div className="flex items-start gap-2">
                <Shield size={12} className="text-safe-500 mt-0.5" />
                <span>One outbound network attempt was blocked. Zero external connections during generation.</span>
              </div>
            </div>
          </Panel>

          <Panel label="SOURCES" title="Grounded Citations">
            <div className="p-4 space-y-2">
              {sources.map((s, i) => (
                <div key={i} className="rounded-lg border border-ivory-300 p-2.5">
                  <div className="flex items-center gap-2">
                    <FileText size={12} className="text-accent-500" />
                    <span className="text-xs font-medium text-graphite-600 truncate">{s.doc}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1 ml-5">
                    <span className="tech-label text-xs text-graphite-400">P.{s.page}</span>
                    <span className="tech-label text-xs text-graphite-400">{s.section}</span>
                  </div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel label="VERIFICATION" title="Checks Performed">
            <div className="p-4 space-y-2">
              {checks.map((c) => (
                <div key={c.label} className="flex items-center justify-between py-1.5 hairline-b last:border-0">
                  <div>
                    <div className="text-xs font-medium text-graphite-600">{c.label}</div>
                    <div className="text-xs text-graphite-400 mt-0.5">{c.detail}</div>
                  </div>
                  {c.status === 'passed' ? <CheckCircle2 size={14} className="text-safe-500" /> : <XCircle size={14} className="text-danger-500" />}
                </div>
              ))}
            </div>
          </Panel>

          {/* Approval actions */}
          <Panel label="DECISION" title="Human Approval Gate">
            <div className="p-4">
              <AnimatePresence mode="wait">
                {decision === 'none' && (
                  <motion.div key="pending" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-2">
                    <div className="rounded-lg border border-amber-400/40 bg-amber-400/5 p-3 mb-3">
                      <div className="flex items-center gap-2">
                        <AlertTriangle size={14} className="text-amber-500" />
                        <span className="tech-label text-xs text-amber-600">AWAITING HUMAN DECISION</span>
                      </div>
                    </div>
                    {canDecide ? (
                      <div className="grid grid-cols-1 gap-2">
                        <Button variant="primary" size="md" icon={<CheckCircle2 size={16} />} onClick={() => setDecision('approved')} className="w-full">Approve Deliverable</Button>
                        <Button variant="secondary" size="md" icon={<Sparkles size={16} />} onClick={() => setDecision('revision')} className="w-full">Request Revision</Button>
                        <Button variant="danger" size="md" icon={<XCircle size={16} />} onClick={() => setDecision('rejected')} className="w-full">Reject</Button>
                      </div>
                    ) : (
                      <div className="rounded-lg border border-ivory-300 bg-ivory-100 p-3 text-sm text-graphite-500">
                        Read-only for the {role} role. Only a Manager can approve, reject or request a revision. This separation of duties is enforced by the gateway in production.
                      </div>
                    )}
                  </motion.div>
                )}
                {decision === 'approved' && (
                  <motion.div key="approved" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="rounded-lg border border-safe-500/30 bg-safe-500/5 p-4 text-center">
                    <CheckCircle2 size={24} className="text-safe-500 mx-auto mb-2" />
                    <div className="tech-label text-xs text-safe-600 mb-1">DELIVERABLE APPROVED</div>
                    <div className="text-xs text-graphite-500">Approval recorded in audit log with hash-chain verification.</div>
                  </motion.div>
                )}
                {decision === 'rejected' && (
                  <motion.div key="rejected" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="rounded-lg border border-danger-500/30 bg-danger-500/5 p-4 text-center">
                    <XCircle size={24} className="text-danger-500 mx-auto mb-2" />
                    <div className="tech-label text-xs text-danger-500 mb-1">DELIVERABLE REJECTED</div>
                    <div className="text-xs text-graphite-500">Agent will revise and resubmit for review.</div>
                  </motion.div>
                )}
                {decision === 'revision' && (
                  <motion.div key="revision" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="rounded-lg border border-amber-400/40 bg-amber-400/5 p-4 text-center">
                    <AlertTriangle size={24} className="text-amber-500 mx-auto mb-2" />
                    <div className="tech-label text-xs text-amber-600 mb-1">REVISION REQUESTED</div>
                    <div className="text-xs text-graphite-500">Agent notified. Deliverable will be updated and resubmitted.</div>
                  </motion.div>
                )}
              </AnimatePresence>
              {decision !== 'none' && (
                <Button variant="ghost" size="sm" className="w-full mt-3" onClick={() => setDecision('none')}>Reset Decision</Button>
              )}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

export default ApprovalView;
