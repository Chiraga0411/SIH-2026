import { useState } from 'react';

import {
  Terminal, FileCode, FolderOpen, Wifi, WifiOff, Shield,
  CheckCircle2, XCircle, Cpu, ArrowRight, Lock,
} from 'lucide-react';
import { Panel, TechnicalLabel, Badge, StatusIndicator, Button } from '@/components/ui/primitives';

const sandboxTabs = ['CODE', 'TERMINAL', 'FILES', 'OUTPUT', 'NETWORK'] as const;
type SandboxTab = typeof sandboxTabs[number];

const codeContent = `import math

# Wall thickness verification per Sample Code cl. 4.2
measured_thickness = 6.2  # mm
min_required = 4.4        # mm
safety_factor = 1.5

margin = measured_thickness - min_required
ratio = measured_thickness / min_required

print(f"Measured: {measured_thickness}mm")
print(f"Required: {min_required}mm")
print(f"Margin:   {margin:.1f}mm")
print(f"Ratio:    {ratio:.2f}")

assert margin > 0, "Wall thickness below minimum"
assert ratio >= safety_factor, "Safety ratio not met"

print("Verification: PASSED")`;

const terminalLines = [
  { type: 'cmd', text: '$ python analysis.py' },
  { type: 'out', text: 'Measured: 6.2mm' },
  { type: 'out', text: 'Required: 4.4mm' },
  { type: 'out', text: 'Margin:   1.8mm' },
  { type: 'out', text: 'Ratio:    1.41' },
  { type: 'out', text: 'Verification: PASSED' },
  { type: 'cmd', text: '$ curl https://external-api.example.com' },
  { type: 'err', text: 'OUTBOUND REQUEST BLOCKED — DENIED' },
  { type: 'err', text: 'NETWORK ACCESS: DENIED' },
];

const sandboxFiles = [
  { name: 'analysis.py', size: '1.2 KB', type: 'py' },
  { name: 'wall_thickness_calc.py', size: '8.4 KB', type: 'py' },
  { name: 'verify_compliance.py', size: '3.1 KB', type: 'py' },
  { name: 'output_results.json', size: '640 B', type: 'json' },
];

export function SandboxView() {
  const [activeTab, setActiveTab] = useState<SandboxTab>('CODE');
  const [networkBlocked, setNetworkBlocked] = useState(true);

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">SANDBOX / ISOLATED CODE EXECUTION</TechnicalLabel>
          <h2 className="text-editorial-sm text-graphite-700">Code Execution Sandbox</h2>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="safe">ISOLATED</Badge>
          <Badge variant="danger">EGRESS DENIED</Badge>
          <Badge variant="accent">CODER-7B</Badge>
        </div>
      </div>

      {/* Architecture visualization */}
      <Panel label="SANDBOX ARCHITECTURE" title="Execution Pipeline">
        <div className="p-4">
          <div className="flex items-center justify-center gap-2 flex-wrap">
            {['AGENT', 'SANDBOX', 'CODE', 'VERIFY', 'RESULT'].map((s, i) => (
              <div key={s} className="flex items-center">
                <div className={`rounded-lg border px-4 py-2.5 ${i === 0 ? 'border-accent-500/40 bg-accent-50' : i === 4 ? 'border-safe-500/40 bg-safe-500/5' : 'border-ivory-300 bg-ivory-50'}`}>
                  <div className="tech-label text-xs text-graphite-500">{s}</div>
                </div>
                {i < 4 && <ArrowRight size={14} className="text-graphite-300 mx-1" />}
              </div>
            ))}
          </div>
        </div>
      </Panel>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main sandbox interface */}
        <div className="lg:col-span-2">
          <Panel dark label="SANDBOX" title="python execution environment" action={
            <StatusIndicator status="success" label="READY" />
          }>
            {/* Tabs */}
            <div className="flex items-center gap-1 px-3 pt-2 hairline-b-dark">
              {sandboxTabs.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium transition-colors ${
                    activeTab === tab ? 'text-accent-300 border-b border-accent-500' : 'text-graphite-200 hover:text-ivory-100'
                  }`}
                >
                  {tab === 'NETWORK' && (networkBlocked ? <WifiOff size={12} /> : <Wifi size={12} />)}
                  {tab === 'CODE' && <FileCode size={12} />}
                  {tab === 'TERMINAL' && <Terminal size={12} />}
                  {tab === 'FILES' && <FolderOpen size={12} />}
                  {tab === 'OUTPUT' && <CheckCircle2 size={12} />}
                  {tab}
                </button>
              ))}
            </div>

            <div className="p-4 min-h-[400px]">
              {activeTab === 'CODE' && (
                <pre className="text-xs font-mono text-graphite-100 leading-relaxed overflow-x-auto">
                  <code>
                    {codeContent.split('\n').map((line, i) => (
                      <div key={i} className="flex">
                        <span className="text-graphite-400 w-8 shrink-0 text-right pr-3">{i + 1}</span>
                        <span className={line.startsWith('#') ? 'text-graphite-300' : line.startsWith('import') ? 'text-accent-300' : 'text-ivory-100'}>{line}</span>
                      </div>
                    ))}
                  </code>
                </pre>
              )}

              {activeTab === 'TERMINAL' && (
                <div className="font-mono text-xs space-y-1">
                  {terminalLines.map((line, i) => (
                    <div key={i} className={line.type === 'err' ? 'text-danger-400' : line.type === 'cmd' ? 'text-accent-300' : 'text-graphite-100'}>
                      {line.text}
                    </div>
                  ))}
                  <div className="flex items-center text-graphite-200">
                    <span className="text-accent-300">$</span>
                    <span className="ml-2 animate-pulse-soft">_</span>
                  </div>
                </div>
              )}

              {activeTab === 'FILES' && (
                <div className="space-y-1">
                  {sandboxFiles.map((f) => (
                    <div key={f.name} className="flex items-center gap-2 px-3 py-2 rounded hover:bg-graphite-700/50 transition-colors cursor-pointer">
                      <FileCode size={14} className="text-accent-300" />
                      <span className="text-sm text-ivory-100 font-mono">{f.name}</span>
                      <span className="tech-label text-xs text-graphite-300 ml-auto">{f.size}</span>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'OUTPUT' && (
                <div className="space-y-3">
                  <div className="rounded-lg border border-safe-500/30 bg-safe-500/5 p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle2 size={16} className="text-safe-400" />
                      <span className="tech-label text-xs text-safe-400">CALCULATION COMPLETED</span>
                    </div>
                    <div className="text-sm text-graphite-100">Wall thickness verification passed. Margin: 1.8mm. Safety ratio: 1.41.</div>
                  </div>
                  <div className="rounded-lg border border-safe-500/30 bg-safe-500/5 p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle2 size={16} className="text-safe-400" />
                      <span className="tech-label text-xs text-safe-400">VERIFICATION PASSED</span>
                    </div>
                    <div className="text-sm text-graphite-100">All assertions passed. Result: APPROVED.</div>
                  </div>
                </div>
              )}

              {activeTab === 'NETWORK' && (
                <div className="space-y-3">
                  <div className={`rounded-lg border p-4 ${networkBlocked ? 'border-danger-500/40 bg-danger-500/10' : 'border-safe-500/30 bg-safe-500/5'}`}>
                    <div className="flex items-center gap-2 mb-3">
                      {networkBlocked ? <XCircle size={16} className="text-danger-400" /> : <CheckCircle2 size={16} className="text-safe-400" />}
                      <span className={`tech-label text-xs ${networkBlocked ? 'text-danger-400' : 'text-safe-400'}`}>
                        {networkBlocked ? 'OUTBOUND REQUEST BLOCKED' : 'NETWORK ACCESS ALLOWED'}
                      </span>
                    </div>
                    <div className="font-mono text-xs text-graphite-100 space-y-1">
                      <div>Source: Sandbox (localhost:9090)</div>
                      <div>Destination: external-api.example.com:443</div>
                      <div>Protocol: HTTPS</div>
                      <div className={networkBlocked ? 'text-danger-400' : 'text-safe-400'}>
                        Result: {networkBlocked ? 'DENIED — Egress policy: DENY_ALL' : 'ALLOWED'}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant={networkBlocked ? 'danger' : 'secondary'} size="sm" onClick={() => setNetworkBlocked(!networkBlocked)}>
                      {networkBlocked ? 'Network: DENIED' : 'Network: ALLOWED'}
                    </Button>
                    <Button variant="ghost" size="sm" className="text-graphite-200" onClick={() => setNetworkBlocked(true)}>Reset</Button>
                  </div>
                </div>
              )}
            </div>
          </Panel>
        </div>

        {/* Right — Network policy + status */}
        <div className="space-y-4">
          <Panel label="EGRESS POLICY" title="Network Rules">
            <div className="p-4 space-y-2">
              <div className="flex items-center justify-between py-2 hairline-b">
                <div className="flex items-center gap-2">
                  <Lock size={14} className="text-danger-400" />
                  <span className="text-sm text-graphite-500">Outbound Internet</span>
                </div>
                <Badge variant="danger">DENY ALL</Badge>
              </div>
              <div className="flex items-center justify-between py-2 hairline-b">
                <div className="flex items-center gap-2">
                  <Shield size={14} className="text-safe-500" />
                  <span className="text-sm text-graphite-500">Local Model Server</span>
                </div>
                <Badge variant="safe">ALLOW</Badge>
              </div>
              <div className="flex items-center justify-between py-2 hairline-b">
                <div className="flex items-center gap-2">
                  <Shield size={14} className="text-safe-500" />
                  <span className="text-sm text-graphite-500">Local Vector DB</span>
                </div>
                <Badge variant="safe">ALLOW</Badge>
              </div>
              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-2">
                  <Cpu size={14} className="text-safe-500" />
                  <span className="text-sm text-graphite-500">File System (isolated)</span>
                </div>
                <Badge variant="safe">ALLOW</Badge>
              </div>
            </div>
          </Panel>

          <Panel label="SANDBOX STATUS" title="Environment">
            <div className="p-4 space-y-2 text-xs">
              {[
                { label: 'CONTAINER', value: 'sandbox-py-01' },
                { label: 'RUNTIME', value: 'Python 3.12' },
                { label: 'CPU LIMIT', value: '2 cores' },
                { label: 'MEMORY', value: '4 GB' },
                { label: 'DISK', value: '512 MB isolated' },
                { label: 'UPTIME', value: '14d 6h' },
              ].map((s) => (
                <div key={s.label} className="flex items-center justify-between py-1">
                  <span className="tech-label text-xs text-graphite-300">{s.label}</span>
                  <span className="text-graphite-500 font-mono">{s.value}</span>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

export default SandboxView;
