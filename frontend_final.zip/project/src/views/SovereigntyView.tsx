import { useState, lazy, Suspense } from 'react';
import { motion } from 'framer-motion';
import {
  Lock,
  Server,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Globe,
  Network,
} from 'lucide-react';
import { Panel, TechnicalLabel, Badge, StatusIndicator, Metric } from '@/components/ui/primitives';
import { localServices, connectionEvents, auditEntries } from '@/data/mockData';
import { verifyChain } from '@/lib/hashChain';
import { useOnlineStatus } from '@/lib/useOnline';
import { DEMO_MODE } from '@/lib/runtime';

import { EffectsGate } from '@/components/three/EffectsGate';
const SovereigntyViz = lazy(() => import('@/components/three/SovereigntyViz'));

export function SovereigntyView() {
  const [showBlocked, setShowBlocked] = useState(false);
  const online = useOnlineStatus();
  const auditOk = verifyChain(auditEntries).ok;

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">SOVEREIGNTY MONITOR / AIR-GAPPED OPERATION</TechnicalLabel>
          <h2 className="text-editorial-md text-graphite-700">Sovereignty Monitor</h2>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="safe">ALL SERVICES LOCAL</Badge>
          <Badge variant="danger">EGRESS: DENY ALL</Badge>
        </div>
      </div>

      {DEMO_MODE && (
        <div className="flex items-start gap-2 rounded-lg border border-amber-400/40 bg-amber-400/5 px-4 py-3 text-sm text-graphite-600">
          <AlertTriangle size={16} className="mt-0.5 shrink-0 text-amber-500" />
          <span>
            Simulated values: the counter, services and connection events below are sample data. Only the browser link state and the audit-chain check are computed live. Use Wireshark as the proof until the backend network monitor is connected.
          </span>
        </div>
      )}

      {/* Main metric */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Panel dark className="relative overflow-hidden lg:col-span-2 h-[400px]">
          <div className="absolute inset-0">
            <EffectsGate fallback={<div className="absolute inset-0 blueprint-grid-dark" />}>
              <Suspense fallback={<div className="absolute inset-0 blueprint-grid-dark" />}>
                <SovereigntyViz />
              </Suspense>
            </EffectsGate>
          </div>
          <div className="relative z-10 p-6">
            <TechnicalLabel className="!text-graphite-200 mb-2">EXTERNAL CONNECTIONS{DEMO_MODE ? ' (SIMULATED)' : ''}</TechnicalLabel>
            <div className="text-7xl font-semibold tracking-tighter text-ivory-100">0</div>
            <div className="flex items-center gap-2 mt-3">
              <div className="h-2 w-2 rounded-full bg-safe-400 animate-pulse-soft" />
              <span className="tech-label text-xs text-safe-400">{DEMO_MODE ? 'DEMO VALUE — CONNECT BACKEND MONITOR' : 'SOVEREIGN — NO EXTERNAL ACCESS'}</span>
            </div>
            <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between">
              <div className="flex items-center gap-2 text-graphite-200">
                <div className="h-1 w-12 bg-safe-400/30 rounded" />
                <span className="tech-label text-xs">LOCAL BOUNDARY</span>
              </div>
              <div className="flex items-center gap-2 text-graphite-200">
                <span className="tech-label text-xs">EXTERNAL NETWORK</span>
                <div className="h-1 w-12 bg-danger-500/30 rounded" />
                <Globe size={12} className="text-danger-400" />
              </div>
            </div>
          </div>
        </Panel>

        <div className="space-y-3">
          <Metric label="BROWSER NETWORK LINK" value={online ? 'ONLINE' : 'OFFLINE'} dark trend="Reported by the browser (live)" />
          <Metric label="DATA MODE" value={DEMO_MODE ? 'DEMO' : 'LIVE'} dark accent trend={DEMO_MODE ? 'Synthetic events' : 'Backend monitor connected'} />
          <Metric label="AUDIT INTEGRITY" value={auditOk ? 'VERIFIED' : 'BROKEN'} dark trend={`${auditEntries.length} events · SHA-256 chain (live check)`} />
        </div>
      </div>

      {/* Local services */}
      <Panel label="LOCAL SERVICES" title="Sovereign Infrastructure" action={
        <StatusIndicator status="success" label="ALL OPERATIONAL" />
      }>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 p-4">
          {localServices.map((s) => (
            <div key={s.id} className="rounded-lg border border-ivory-300 bg-ivory-50 p-3 hover:shadow-panel transition-all">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Server size={14} className="text-accent-500" />
                  <span className="text-sm font-medium text-graphite-600">{s.name}</span>
                </div>
                <StatusIndicator status={s.status === 'operational' ? 'success' : 'warning'} label="OK" />
              </div>
              <div className="text-xs text-graphite-300 mb-2">{s.description}</div>
              <div className="flex items-center justify-between">
                <span className="tech-label text-xs text-graphite-300">UPTIME: {s.uptime}</span>
                <span className="tech-label text-xs text-graphite-300">{s.connections} CONN</span>
              </div>
            </div>
          ))}
        </div>
      </Panel>

      {/* Connection events */}
      <Panel label="CONNECTION EVENTS" title="Recent Network Activity" action={
        <button onClick={() => setShowBlocked(!showBlocked)} className="flex items-center gap-1 text-xs text-accent-500 hover:text-accent-600">
          {showBlocked ? 'Show All' : 'Show Blocked Only'}
        </button>
      }>
        <div className="divide-y divide-ivory-200">
          {(showBlocked ? connectionEvents.filter(e => e.type === 'denied-egress') : connectionEvents).map((e) => {
            const isBlocked = e.type === 'denied-egress';
            return (
              <motion.div
                key={e.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-3 px-4 py-3"
              >
                <div className={`flex h-8 w-8 items-center justify-center rounded ${isBlocked ? 'bg-danger-500/10' : 'bg-safe-500/10'}`}>
                  {isBlocked ? <XCircle size={14} className="text-danger-500" /> : <CheckCircle2 size={14} className="text-safe-500" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="tech-label text-xs text-graphite-300">{e.time}</span>
                    <span className="tech-label text-xs text-graphite-300">{e.protocol}</span>
                  </div>
                  <div className="text-sm text-graphite-600 mt-0.5">{e.source} → {e.destination}</div>
                </div>
                <div className="text-right">
                  {isBlocked ? (
                    <div>
                      <div className="flex items-center gap-1 justify-end">
                        <Lock size={12} className="text-danger-500" />
                        <span className="tech-label text-xs text-danger-500">BLOCKED</span>
                      </div>
                      <div className="text-xs text-graphite-300 mt-0.5">{e.result}</div>
                    </div>
                  ) : (
                    <div>
                      <div className="flex items-center gap-1 justify-end">
                        <Network size={12} className="text-safe-500" />
                        <span className="tech-label text-xs text-safe-500">ALLOWED</span>
                      </div>
                      <div className="text-xs text-graphite-300 mt-0.5">{e.result}</div>
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </Panel>

      {/* Egress policy */}
      <Panel label="EGRESS POLICY" title="Network Security Rules">
        <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            { rule: 'Default Egress', status: 'DENY', icon: Lock, color: 'danger' as const },
            { rule: 'External APIs', status: 'DENY', icon: Globe, color: 'danger' as const },
            { rule: 'Local Model Server (127.0.0.1:8080)', status: 'ALLOW', icon: Server, color: 'safe' as const },
            { rule: 'Local Vector DB (127.0.0.1:6332)', status: 'ALLOW', icon: Database, color: 'safe' as const },
          ].map((r) => {
            const Icon = r.icon;
            return (
              <div key={r.rule} className="flex items-center justify-between rounded-lg border border-ivory-300 bg-ivory-50 p-3">
                <div className="flex items-center gap-2">
                  <Icon size={14} className={r.color === 'danger' ? 'text-danger-500' : 'text-safe-500'} />
                  <span className="text-sm text-graphite-500">{r.rule}</span>
                </div>
                <Badge variant={r.color}>{r.status}</Badge>
              </div>
            );
          })}
        </div>
      </Panel>
    </div>
  );
}

function Database({ size, className }: { size: number; className?: string }) {
  return <Server size={size} className={className} />;
}

export default SovereigntyView;
