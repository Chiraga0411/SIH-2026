import { useState, lazy, Suspense } from 'react';
import { motion } from 'framer-motion';
import {
  Cpu,
  BookOpen,
  Activity,
  Server,
  ShieldCheck,
  FileText,
  ArrowUpRight,
} from 'lucide-react';
import { Metric, Panel, TechnicalLabel, Badge, StatusIndicator } from '@/components/ui/primitives';
import { jobs, projects, models, auditEntries, documents } from '@/data/mockData';
import { verifyChain } from '@/lib/hashChain';
import { useSession } from '@/lib/session';
import { useOnlineStatus } from '@/lib/useOnline';
import { DEMO_MODE } from '@/lib/runtime';

import { EffectsGate } from '@/components/three/EffectsGate';
const SystemField = lazy(() => import('@/components/three/SystemField'));

const systemNodes = [
  { id: 'n1', label: 'MODEL ROUTER', desc: '5 registered · 2 resident in GPU memory' },
  { id: 'n2', label: 'AGENT', desc: '3 active agents · 7 tasks' },
  { id: 'n3', label: 'KNOWLEDGE', desc: '14 sources indexed · 1,247 passages' },
  { id: 'n4', label: 'TOOLS', desc: '6 tools available · all local' },
  { id: 'n5', label: 'SANDBOX', desc: 'Isolated · egress denied' },
  { id: 'n6', label: 'DELIVERABLES', desc: '5 generated · 3 approved' },
];

export function OverviewView({ onNavigate }: { onNavigate: (v: string) => void }) {
  const [activeNode, setActiveNode] = useState<string | null>('n2');
  const { role } = useSession();
  const online = useOnlineStatus();
  const auditOk = verifyChain(auditEntries).ok;
  const runningJobs = jobs.filter((j) => j.status === 'RUNNING');
  const queuedJobs = jobs.filter((j) => j.status === 'QUEUED');
  const activeAgents = new Set(runningJobs.map((j) => j.agent)).size;
  const queuePos: Record<string, number> = {};
  jobs.filter((j) => j.status === 'QUEUED').forEach((j, i) => { queuePos[j.id] = i + 1; });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <TechnicalLabel className="mb-2">DEMO-IA-2026 / ENGINEERING OPERATIONS</TechnicalLabel>
          <h2 className="text-editorial-md text-graphite-700">Good morning, {role}.</h2>
          <p className="text-sm text-graphite-400 mt-1">{DEMO_MODE
              ? 'Demo build with synthetic sample data. Live network and audit indicators activate when the backend is connected.'
              : 'All systems local. Sovereignty monitor connected.'}</p>
        </div>
        <div className="flex items-center gap-2">
          {DEMO_MODE ? <Badge variant="warning">DEMO DATA</Badge> : <Badge variant="safe">LIVE</Badge>}
          <Badge variant="accent">ON-PREMISE</Badge>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <Metric label="LOCAL MODELS" value={models.length} accent trend={`${models.filter((m) => m.status === 'loaded').length} resident`} />
        <Metric label="ACTIVE AGENTS" value={activeAgents} trend={`${queuedJobs.length} tasks queued`} />
        <Metric label="KNOWLEDGE DOCS" value={documents.length} trend={`${documents.filter((d) => d.status === 'indexed').length} indexed`} />
        <Metric label="RUNNING JOBS" value={runningJobs.length} accent trend={`${queuedJobs.length} queued`} />
        <Metric label="NETWORK LINK" value={online ? 'ONLINE' : 'OFFLINE'} accent trend="Browser-reported" />
        <Metric label="AUDIT CHAIN" value={auditOk ? 'OK' : 'BROKEN'} trend={`${auditEntries.length} events re-hashed`} />
      </div>

      {/* System Field 3D */}
      <Panel className="relative overflow-hidden h-[360px]" label="SYSTEM FIELD" title="Sovereign Intelligence Environment" action={
        <Badge variant="default">6 SERVICES CONNECTED</Badge>
      }>
        <div className="absolute inset-0">
          <EffectsGate fallback={<div className="absolute inset-0 blueprint-grid" />}>
            <Suspense fallback={<div className="absolute inset-0 blueprint-grid" />}>
              <SystemField activeId={activeNode} />
            </Suspense>
          </EffectsGate>
        </div>
        {/* Node selector overlays */}
        <div className="absolute bottom-4 left-4 right-4 flex flex-wrap gap-2 z-10">
          {systemNodes.map((n) => (
            <button
              key={n.id}
              onClick={() => setActiveNode(activeNode === n.id ? null : n.id)}
              className={`rounded-lg border px-3 py-2 text-left transition-all ${
                activeNode === n.id
                  ? 'border-accent-500/60 bg-ivory-50/90 backdrop-blur shadow-panel'
                  : 'border-ivory-300/60 bg-ivory-50/70 backdrop-blur hover:bg-ivory-50/90'
              }`}
            >
              <div className="tech-label text-xs text-accent-500">{n.label}</div>
              <div className="text-xs text-graphite-400 mt-0.5">{n.desc}</div>
            </button>
          ))}
        </div>
        {/* Corner annotation */}
        <div className="absolute top-4 right-4 mesh-annotation text-graphite-400">
          INTERACTIVE / CLICK NODES
        </div>
      </Panel>

      {/* Job Queue + Projects */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel label="JOB QUEUE" title="Live Jobs" action={<StatusIndicator status="running" label="2 ACTIVE" animate />}>
          <div className="divide-y divide-ivory-200">
            {jobs.map((job) => (
              <div key={job.id} className="flex items-center gap-3 px-4 py-3 hover:bg-ivory-100/50 transition-colors">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-graphite-600 truncate">{job.name}</div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="tech-label text-xs text-graphite-400">{job.project}</span>
                    <span className="tech-label text-xs text-graphite-400">·</span>
                    <span className="tech-label text-xs text-graphite-400">{job.agent}</span>
                  </div>
                </div>
                <div className="w-24">
                  {job.status === 'RUNNING' && (
                    <div>
                      <div className="h-1 bg-ivory-200 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-accent-500"
                          animate={{ width: `${job.progress}%` }}
                          transition={{ duration: 1, ease: 'easeOut' }}
                        />
                      </div>
                      <div className="tech-label text-xs text-accent-500 mt-1">{job.progress}%</div>
                    </div>
                  )}
                  {job.status === 'WAITING FOR APPROVAL' && <StatusIndicator status="warning" label="APPROVAL" />}
                  {job.status === 'QUEUED' && <StatusIndicator status="pending" label={`QUEUE #${queuePos[job.id]}`} />}
                  {job.status === 'COMPLETED' && <StatusIndicator status="success" label="DONE" />}
                  {job.status === 'BLOCKED' && <StatusIndicator status="blocked" label="BLOCKED" />}
                </div>
              </div>
            ))}
          </div>
        </Panel>

        <Panel label="PROJECTS" title="Active Workspaces" action={
          <button onClick={() => onNavigate('projects')} className="flex items-center gap-1 text-xs text-accent-500 hover:text-accent-600">
            View all <ArrowUpRight size={12} />
          </button>
        }>
          <div className="divide-y divide-ivory-200">
            {projects.filter(p => p.status === 'active').map((p) => (
              <div
                key={p.id}
                className="flex items-center gap-3 px-4 py-3 hover:bg-ivory-100/50 transition-colors cursor-pointer"
                onClick={() => onNavigate('projects')}
              >
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-ivory-200 border border-ivory-300">
                  <FileText size={16} className="text-graphite-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-graphite-600 truncate">{p.name}</div>
                  <div className="tech-label text-xs text-graphite-400 mt-0.5">{p.code}</div>
                </div>
                <div className="flex items-center gap-3 text-xs text-graphite-400">
                  <span className="flex items-center gap-1"><FileText size={12} />{p.documents}</span>
                  <span className="flex items-center gap-1"><Cpu size={12} />{p.agents}</span>
                  <span className="flex items-center gap-1"><Activity size={12} />{p.tasks}</span>
                </div>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { icon: Cpu, label: 'Agent Workspace', view: 'agent', desc: 'Run agentic tasks' },
          { icon: BookOpen, label: 'Knowledge Base', view: 'knowledge', desc: 'Search documents' },
          { icon: Server, label: 'Model Router', view: 'models', desc: 'Manage local models' },
          { icon: ShieldCheck, label: 'Sovereignty', view: 'sovereignty', desc: 'Monitor connections' },
        ].map((a) => {
          const Icon = a.icon;
          return (
            <button
              key={a.label}
              onClick={() => onNavigate(a.view)}
              className="group rounded-xl panel-ivory p-4 text-left transition-all hover:shadow-panel hover:border-accent-200/50"
            >
              <Icon size={20} className="text-accent-500 mb-3" />
              <div className="text-sm font-medium text-graphite-600">{a.label}</div>
              <div className="text-xs text-graphite-400 mt-0.5">{a.desc}</div>
              <ArrowUpRight size={14} className="text-graphite-200 mt-2 group-hover:text-accent-500 transition-colors" />
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default OverviewView;
