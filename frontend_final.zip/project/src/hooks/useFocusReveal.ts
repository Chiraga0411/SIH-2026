import { useEffect, useRef, useState } from 'react';

// Focus Reveal — text comes into computational focus as user scrolls
export function useFocusReveal<T extends HTMLElement = HTMLDivElement>(threshold = 0.3) {
  const ref = useRef<T>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf = 0;

    const update = () => {
      const rect = el.getBoundingClientRect();
      const winH = window.innerHeight;
      // 0 when element is below viewport, 1 when centered
      const center = rect.top + rect.height / 2;
      const p = Math.max(0, Math.min(1, 1 - (center - winH * 0.5) / (winH * 0.6)));
      setProgress(p);
    };

    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(update);
    };

    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      cancelAnimationFrame(raf);
    };
  }, [threshold]);

  return { ref, progress };
}

// Apply focus reveal styling to a heading
export function focusRevealStyle(progress: number) {
  const blur = Math.max(0, (1 - progress) * 6);
  const opacity = 0.2 + progress * 0.8;
  const letterSpacing = `${(1 - progress) * 0.08}em`;
  const transform = `translateY(${(1 - progress) * 20}px)`;
  return {
    filter: `blur(${blur}px)`,
    opacity,
    letterSpacing,
    transform,
  };
}
