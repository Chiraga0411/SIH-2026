# SOVEREIGN AI — Frontend (SIH 2026, PS SIH26117)

React + TypeScript + Tailwind UI for the on-premise agentic AI workbench.
It runs **fully offline**: fonts are bundled, there are no CDN links, and the code makes no network requests.

> **Demo mode.** With no backend configured, every number on screen is synthetic sample data
> and the top bar shows `DATA: DEMO`. Do not present these screens as measured proof.
> Wire the backend (see below) or label screenshots "UI concept".

## Run

```bash
npm install          # needs internet once, to fetch packages
npm run dev          # http://localhost:5173
npm run build        # production build in dist/
npm run typecheck    # TypeScript check
```

Requires Node.js 18 or newer. There is no lock file in this zip; `npm install` creates one, commit it.

### Two-device demo (two users, no internet)
```bash
npm run dev -- --host
```
Open `http://<laptop-LAN-IP>:5173` on a second device on the same Wi-Fi/hotspot. Sign in as an Engineer on one
device and a Manager on the other. Internet can stay off the whole time.

## Roles (demo)

| Role | Can do | Clearance |
|---|---|---|
| Engineer | Run tasks, draft work, **cannot approve** (submits to a manager) | Internal |
| Manager | Approve / reject / request revision, view audit | Restricted |
| Admin | Add models, view audit, read-only on approvals | Internal |

Documents carry `Public / Internal / Restricted` labels. Search and citations are filtered by clearance
**before** retrieval; hidden items show only a count. In production the Node gateway must enforce all of this
(JWT + server-side checks). The UI only mirrors the rules (`src/lib/access.ts`).

## Screens

Overview · Agent Workspace (task box, queue position, plan/trace, approval) · Knowledge (citations, clearance,
prompt-injection quarantine) · Multimodal · Models (registry, add model) · Sandbox · Projects (members,
private/shared activity) · Deliverables · Approval Center · Audit (real SHA-256 hash chain, *Verify integrity*,
*Simulate tampering*) · Sovereignty · Benchmarks (enter measured numbers, charts and a copy-ready summary).

The **Visual effects** switch in the sidebar turns the WebGL scenes off. Turn them off while the language
model is running so the browser does not compete with it for the GPU.

## What is real and what is sample

| Real in this build | Sample data until you connect a backend |
|---|---|
| Role checks in the UI, clearance filtering | Model names and sizes (`src/data/mockData.ts`) |
| SHA-256 hash chain and tamper detection | Jobs, trace events, connection events |
| Browser online/offline indicator (`navigator.onLine`) | "External connections" counter (labelled simulated) |
| Task box, simulated queue, private/shared toggle | Documents, projects, members, activity |
| Benchmarks page (your typed numbers) | Everything the agent "does" during a run |

`navigator.onLine` only says whether the device has a network link. It is not proof that no traffic left the
machine. Use Wireshark or a backend monitor for that.

## Connect the backend

1. Copy `.env.example` to `.env` and set `VITE_API_BASE` to your **local/LAN** gateway URL. `DEMO_MODE` in
   `src/lib/runtime.ts` then turns off and the badges read `LIVE`.
2. Replace the arrays in `src/data/mockData.ts` with API calls. Suggested endpoints: `/api/jobs`, `/api/models`,
   `/api/documents`, `/api/audit`, `/api/status/network`, `/api/projects`.
3. Feed the Sovereignty counter from a real monitor (connections per process, split into local and external).
4. Keep the sample data labelled until then.

Before you show the sample models to judges, replace the placeholder names (`General-8B`, `Coder-7B`, `Vision-VL`,
...) with the real model tags you run and the numbers you measured (use the **Benchmarks** page).

## Project layout

```
src/
  lib/          access.ts (roles, clearance) · session.tsx · hashChain.ts · runtime.ts · useOnline.ts
  views/        one file per screen
  components/   layout/AppShell · ui/primitives · three/ (WebGL scenes + EffectsGate)
  data/         mockData.ts (synthetic sample data)
```

## Changes in this version

- Fonts bundled with `@fontsource` (no Google Fonts request); removed the unused cloud SDK and generator metadata
- Labels raised to 12 px minimum; sample data marked as synthetic; invented model names, org codes and standard clauses removed
- Task box, simulated queue position, private/shared toggle, role-gated approvals
- Clearance labels with retrieval-time filtering, prompt-injection quarantine demo
- Projects with members and shared/private activity
- Real SHA-256 audit chain with verify and tamper demo
- Sovereignty and network indicators labelled simulated / browser-reported
- Visual-effects switch now controls every WebGL scene
- New Benchmarks page
